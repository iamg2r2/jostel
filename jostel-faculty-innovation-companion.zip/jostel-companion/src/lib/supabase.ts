import { createClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined

// The app renders its "configuration needed" screen rather than silently
// pretending cloud persistence works when credentials are absent.
export const isSupabaseConfigured = Boolean(
  url && anonKey && !url.includes('YOUR-PROJECT-REF')
)

// Deliberately untyped against the Database schema: the strict generic makes
// PostgREST's filter-builder overloads collapse to `never` in several call
// shapes used below. Row/Insert/Update shapes are still documented in
// src/types/database.ts and used directly as plain types (see types/domain.ts).
// A safe, inert client is still created so imports never crash the app;
// every call will simply fail until real credentials are supplied.
export const supabase = createClient(
  url || 'https://placeholder.supabase.co',
  anonKey || 'placeholder-anon-key',
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
    },
  }
)
