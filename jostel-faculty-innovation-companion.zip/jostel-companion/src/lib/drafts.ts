// Local-only draft fallback used when the network briefly drops mid-form.
// This is NOT the primary data store — Supabase is — it only prevents lost
// work for the few seconds/minutes until connectivity returns.

const PREFIX = 'jostel_draft_'

export function saveDraft(key: string, data: unknown) {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify({ data, savedAt: Date.now() }))
  } catch {
    // localStorage can fail (quota, private mode) — draft saving is best-effort.
  }
}

export function loadDraft<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(PREFIX + key)
    if (!raw) return null
    return JSON.parse(raw).data as T
  } catch {
    return null
  }
}

export function clearDraft(key: string) {
  try {
    localStorage.removeItem(PREFIX + key)
  } catch {
    // ignore
  }
}

export function listDraftKeys(): string[] {
  try {
    return Object.keys(localStorage)
      .filter((k) => k.startsWith(PREFIX))
      .map((k) => k.slice(PREFIX.length))
  } catch {
    return []
  }
}
