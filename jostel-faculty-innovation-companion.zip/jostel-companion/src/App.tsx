import { Routes, Route } from 'react-router-dom'
import { isSupabaseConfigured } from './lib/supabase'
import ConfigNeeded from './components/ConfigNeeded'
import ProtectedRoute from './components/ProtectedRoute'

import Landing from './pages/Landing'
import Login from './pages/Login'

import FacultyHome from './pages/faculty/FacultyHome'
import PedagogyExplorer from './pages/faculty/PedagogyExplorer'
import PedagogyDetail from './pages/faculty/PedagogyDetail'
import ThinkingLevels from './pages/faculty/ThinkingLevels'
import AssessmentHelper from './pages/faculty/AssessmentHelper'
import ActivityForm from './pages/faculty/ActivityForm'
import MyActivities from './pages/faculty/MyActivities'

import TrainerHome from './pages/trainer/TrainerHome'
import TrainerDepartment from './pages/trainer/TrainerDepartment'
import TrainerFacultyRecord from './pages/trainer/TrainerFacultyRecord'

import AdminHome from './pages/admin/AdminHome'
import AdminDepartments from './pages/admin/AdminDepartments'
import AdminPedagogies from './pages/admin/AdminPedagogies'
import AdminAssessments from './pages/admin/AdminAssessments'

export default function App() {
  if (!isSupabaseConfigured) {
    return (
      <Routes>
        <Route path="*" element={<ConfigNeeded />} />
      </Routes>
    )
  }

  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />

      <Route path="/faculty" element={<ProtectedRoute><FacultyHome /></ProtectedRoute>} />
      <Route path="/faculty/pedagogy-explorer" element={<ProtectedRoute><PedagogyExplorer /></ProtectedRoute>} />
      <Route path="/faculty/pedagogy/:id" element={<ProtectedRoute><PedagogyDetail /></ProtectedRoute>} />
      <Route path="/faculty/thinking-levels" element={<ProtectedRoute><ThinkingLevels /></ProtectedRoute>} />
      <Route path="/faculty/assessment-helper" element={<ProtectedRoute><AssessmentHelper /></ProtectedRoute>} />
      <Route path="/faculty/activities" element={<ProtectedRoute><MyActivities /></ProtectedRoute>} />
      <Route path="/faculty/activities/:id" element={<ProtectedRoute><ActivityForm /></ProtectedRoute>} />

      <Route path="/trainer" element={<ProtectedRoute allow={['trainer', 'admin']}><TrainerHome /></ProtectedRoute>} />
      <Route path="/trainer/departments/:id" element={<ProtectedRoute allow={['trainer', 'admin']}><TrainerDepartment /></ProtectedRoute>} />
      <Route path="/trainer/faculty/:id" element={<ProtectedRoute allow={['trainer', 'admin']}><TrainerFacultyRecord /></ProtectedRoute>} />

      <Route path="/admin" element={<ProtectedRoute allow={['admin']}><AdminHome /></ProtectedRoute>} />
      <Route path="/admin/departments" element={<ProtectedRoute allow={['admin']}><AdminDepartments /></ProtectedRoute>} />
      <Route path="/admin/pedagogies" element={<ProtectedRoute allow={['admin']}><AdminPedagogies /></ProtectedRoute>} />
      <Route path="/admin/assessments" element={<ProtectedRoute allow={['admin']}><AdminAssessments /></ProtectedRoute>} />

      <Route path="*" element={<Landing />} />
    </Routes>
  )
}
