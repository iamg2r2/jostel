export const EVIDENCE_GUIDANCE = {
  message:
    'Collect evidence that genuinely exists. Do not create documentation solely to make an activity appear innovative.',
  categories: [
    {
      phase: 'Before',
      items: ['Learning outcome', 'Lesson / activity plan', 'Task sheet', 'Rubric'],
    },
    {
      phase: 'During',
      items: ['Classroom photographs', 'LMS activity', 'Student interaction', 'Group work', 'Drafts', 'Milestones'],
    },
    {
      phase: 'After',
      items: ['Student artefacts', 'Assessment results', 'Rubrics', 'Feedback', 'Revised work', 'Student reflection', 'Faculty reflection'],
    },
  ],
}

export const EVIDENCE_READINESS_CHECKLIST = [
  'Learning outcome',
  'Activity implemented',
  'Student participation evidence',
  'Student artefact',
  'Assessment instrument',
  'Feedback',
  'Student outcome',
  'Reflection',
]
