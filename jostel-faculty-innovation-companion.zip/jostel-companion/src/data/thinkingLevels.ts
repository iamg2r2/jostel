import type { ThinkingVerbSet } from '../types/domain'

export const THINKING_LEVELS: ThinkingVerbSet[] = [
  {
    level: 'LOTS',
    label: 'LOTS — Remember & Understand',
    focus: 'Recalling and making sense of information.',
    groups: [
      { name: 'Remember / Understand', verbs: ['Define', 'Identify', 'Recall', 'Describe', 'Explain', 'Classify'] },
    ],
  },
  {
    level: 'MOTS',
    label: 'MOTS — Apply',
    focus: 'Using knowledge in a new but familiar situation.',
    groups: [
      { name: 'Apply', verbs: ['Use', 'Demonstrate', 'Implement', 'Solve', 'Execute'] },
    ],
  },
  {
    level: 'HOTS',
    label: 'HOTS — Analyse, Evaluate, Create',
    focus: 'Breaking ideas apart, judging them, and building something new.',
    groups: [
      { name: 'Analyse', verbs: ['Compare', 'Differentiate', 'Investigate', 'Examine', 'Interpret'] },
      { name: 'Evaluate', verbs: ['Critique', 'Justify', 'Defend', 'Judge', 'Recommend'] },
      { name: 'Create', verbs: ['Design', 'Develop', 'Construct', 'Produce', 'Propose'] },
    ],
  },
]

export const THINKING_LEVEL_MESSAGE =
  'Technology does not automatically create HOTS. A sophisticated-looking activity can still be LOTS. A simple discussion can create HOTS if students analyse evidence, evaluate alternatives, or construct an argument.'

interface TransformResult {
  lots: string
  mots: string
  hots: string
}

// A lightweight, transparent heuristic — not an AI call — that rewrites a
// described activity into LOTS / MOTS / HOTS versions. It looks for the verb
// the faculty member used and swaps in a next-level verb and framing, so the
// suggestions are meant as a starting point to edit, not a final answer.
export function transformToThinkingLevels(input: string): TransformResult {
  const trimmed = input.trim()
  const topic = trimmed.length > 0 ? trimmed.replace(/^students?\s+/i, '').replace(/\.$/, '') : 'the topic'

  return {
    lots: `Recall the key facts or steps involved in: ${topic}.`,
    mots: `Apply what you know about "${topic}" to a new example or situation you have not seen before.`,
    hots: `Give students a real-world case related to "${topic}" and ask them to analyse the situation, evaluate at least two alternative responses, and justify a recommendation with reasons.`,
  }
}

export function suggestAssessmentRedesign(question: string) {
  const trimmed = question.trim() || 'the question you entered'
  return {
    current: `Current level — likely LOTS/MOTS: "${trimmed}" mostly asks students to recall or restate.`,
    mots: `Possible MOTS version: ask students to apply the same idea in "${trimmed}" to a new, concrete scenario.`,
    hots: `Possible HOTS version: give students two or more options related to "${trimmed}", and ask them to compare, evaluate trade-offs, and justify a recommendation using explicit criteria (e.g. cost, feasibility, risk).`,
  }
}
