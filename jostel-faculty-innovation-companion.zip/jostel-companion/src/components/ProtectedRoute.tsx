import { type ReactNode } from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import type { Role } from '../types/database'

export default function ProtectedRoute({ children, allow }: { children: ReactNode; allow?: Role[] }) {
  const { session, profile, loading } = useAuth()

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-ink-700">Loading…</div>
  }
  if (!session) return <Navigate to="/login" replace />
  if (allow && profile && !allow.includes(profile.role)) {
    return <Navigate to="/faculty" replace />
  }
  return <>{children}</>
}
