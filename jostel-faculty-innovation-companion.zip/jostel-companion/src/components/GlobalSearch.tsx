import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../contexts/AuthContext'
import { THINKING_LEVELS } from '../data/thinkingLevels'

interface Result {
  kind: string
  label: string
  sublabel?: string
  onSelect: () => void
}

export default function GlobalSearch({ onClose }: { onClose: () => void }) {
  const [q, setQ] = useState('')
  const [results, setResults] = useState<Result[]>([])
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()
  const { session } = useAuth()

  useEffect(() => {
    const term = q.trim()
    if (term.length < 2) {
      setResults([])
      return
    }
    let cancelled = false
    setLoading(true)
    const timer = setTimeout(async () => {
      const found: Result[] = []

      const [{ data: pedagogies }, { data: assessments }, { data: departments }] = await Promise.all([
        supabase.from('pedagogies').select('id, name').ilike('name', `%${term}%`).limit(5),
        supabase.from('assessments').select('id, name').ilike('name', `%${term}%`).limit(5),
        supabase.from('departments').select('id, name').ilike('name', `%${term}%`).limit(5),
      ])

      pedagogies?.forEach((p) =>
        found.push({
          kind: 'Pedagogy',
          label: p.name,
          onSelect: () => navigate(`/faculty/pedagogy/${p.id}`),
        })
      )
      assessments?.forEach((a) =>
        found.push({
          kind: 'Assessment',
          label: a.name,
          onSelect: () => navigate('/faculty/assessment-helper'),
        })
      )
      departments?.forEach((d) =>
        found.push({
          kind: 'Department',
          label: d.name,
          onSelect: () => navigate('/faculty/pedagogy-explorer'),
        })
      )

      THINKING_LEVELS.forEach((level) => {
        if (level.level.toLowerCase().includes(term.toLowerCase()) || level.label.toLowerCase().includes(term.toLowerCase())) {
          found.push({ kind: 'Thinking level', label: level.label, onSelect: () => navigate('/faculty/thinking-levels') })
        }
        level.groups.forEach((g) => {
          g.verbs.forEach((v) => {
            if (v.toLowerCase().includes(term.toLowerCase())) {
              found.push({
                kind: level.level,
                label: v,
                sublabel: g.name,
                onSelect: () => navigate('/faculty/thinking-levels'),
              })
            }
          })
        })
      })

      if (session) {
        const { data: activities } = await supabase
          .from('activities')
          .select('id, title')
          .eq('faculty_id', session.user.id)
          .ilike('title', `%${term}%`)
          .limit(5)
        activities?.forEach((a) =>
          found.push({ kind: 'Your activity', label: a.title, onSelect: () => navigate(`/faculty/activities/${a.id}`) })
        )
      }

      if (!cancelled) {
        setResults(found.slice(0, 20))
        setLoading(false)
      }
    }, 250)

    return () => {
      cancelled = true
      clearTimeout(timer)
    }
  }, [q, navigate, session])

  return (
    <div className="fixed inset-0 z-50 bg-ink-900/40 flex items-start justify-center pt-24 px-4" onClick={onClose}>
      <div className="surface-card w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
        <input
          autoFocus
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search pedagogy, assessment, department, HOTS, LOTS, activity..."
          className="field-input mb-3"
        />
        {loading && <p className="text-sm text-ink-700/60">Searching…</p>}
        <ul className="max-h-80 overflow-y-auto divide-y divide-azure-50">
          {results.map((r, i) => (
            <li key={i}>
              <button
                onClick={() => {
                  r.onSelect()
                  onClose()
                }}
                className="w-full text-left py-2.5 px-1 hover:bg-azure-50 rounded-lg flex items-center justify-between"
              >
                <span>{r.label}{r.sublabel ? <span className="text-ink-700/50"> · {r.sublabel}</span> : null}</span>
                <span className="pill bg-azure-50 text-azure-700">{r.kind}</span>
              </button>
            </li>
          ))}
          {!loading && q.trim().length >= 2 && results.length === 0 && (
            <li className="py-4 text-sm text-ink-700/60">No matches yet — try a different term.</li>
          )}
        </ul>
      </div>
    </div>
  )
}
