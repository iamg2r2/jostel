export default function ConfigNeeded() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="surface-card max-w-lg text-center space-y-4">
        <h1 className="text-2xl">Almost there</h1>
        <p className="text-ink-700">
          This app needs to be connected to a Supabase project before it can store
          accounts, activities or evidence. Copy <code className="px-1 bg-azure-50 rounded">.env.example</code>{' '}
          to <code className="px-1 bg-azure-50 rounded">.env.local</code>, fill in your project's URL and anon
          key, then restart the dev server (or rebuild for deployment).
        </p>
        <p className="text-sm text-ink-700/70">
          See <code className="px-1 bg-azure-50 rounded">README.md</code> for full setup steps, including the
          database schema and seed data to run in the Supabase SQL editor.
        </p>
      </div>
    </div>
  )
}
