import { NavLink, useNavigate } from 'react-router-dom'
import { type ReactNode, useState } from 'react'
import { useAuth } from '../contexts/AuthContext'
import GlobalSearch from './GlobalSearch'

const navLinkClass = ({ isActive }: { isActive: boolean }) =>
  `px-3 py-2 rounded-full text-sm font-medium transition ${
    isActive ? 'bg-azure-500 text-white' : 'text-ink-700 hover:bg-azure-50'
  }`

export default function AppShell({ children }: { children: ReactNode }) {
  const { profile, signOut } = useAuth()
  const navigate = useNavigate()
  const [searchOpen, setSearchOpen] = useState(false)

  const role = profile?.role ?? 'faculty'
  const homePath = role === 'admin' ? '/admin' : role === 'trainer' ? '/trainer' : '/faculty'

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-azure-100 bg-white/80 backdrop-blur sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <button onClick={() => navigate(homePath)} className="flex items-center gap-2 shrink-0">
            <svg width="28" height="28" viewBox="0 0 64 64" aria-hidden>
              <rect width="64" height="64" rx="14" fill="#087EA4" />
              <path d="M20 18h24M20 32h24M20 46h16" stroke="#EF8A3A" strokeWidth="5" strokeLinecap="round" />
            </svg>
            <span className="font-display text-lg text-ink-900 hidden sm:inline">JosTEL</span>
          </button>

          <nav className="hidden md:flex items-center gap-1">
            <NavLink to="/faculty" className={navLinkClass}>Faculty</NavLink>
            {(role === 'trainer' || role === 'admin') && (
              <NavLink to="/trainer" className={navLinkClass}>Trainer</NavLink>
            )}
            {role === 'admin' && <NavLink to="/admin" className={navLinkClass}>Admin</NavLink>}
          </nav>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setSearchOpen(true)}
              className="btn-secondary !px-4 !py-2 text-sm"
              aria-label="Search"
            >
              Search
            </button>
            <span className="hidden sm:inline text-sm text-ink-700">{profile?.name}</span>
            <button onClick={() => signOut()} className="text-sm text-ink-700 hover:text-tangerine-600">
              Sign out
            </button>
          </div>
        </div>
        <nav className="md:hidden flex items-center gap-1 px-4 pb-3">
          <NavLink to="/faculty" className={navLinkClass}>Faculty</NavLink>
          {(role === 'trainer' || role === 'admin') && (
            <NavLink to="/trainer" className={navLinkClass}>Trainer</NavLink>
          )}
          {role === 'admin' && <NavLink to="/admin" className={navLinkClass}>Admin</NavLink>}
        </nav>
      </header>

      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-8">{children}</main>

      {searchOpen && <GlobalSearch onClose={() => setSearchOpen(false)} />}

      <footer className="text-center text-xs text-ink-700/60 py-6">
        JosTEL Faculty Innovation Companion
      </footer>
    </div>
  )
}
