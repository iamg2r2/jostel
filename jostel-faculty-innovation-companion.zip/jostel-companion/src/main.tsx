import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App'
import { AuthProvider } from './contexts/AuthContext'
import { DraftSyncProvider } from './contexts/DraftSyncContext'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <DraftSyncProvider>
          <App />
        </DraftSyncProvider>
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>
)
