// Hand-written mirror of the Supabase schema in /supabase/schema.sql.
// Regenerate with `supabase gen types typescript` once your project is live
// if you'd rather have this generated automatically.

export type Role = 'faculty' | 'trainer' | 'admin'
export type ThinkingLevel = 'LOTS' | 'MOTS' | 'HOTS'
export type ActivityStatus = 'draft' | 'in_progress' | 'completed'
export type TrainerStatus = 'not_started' | 'discussed' | 'in_progress' | 'evidence_collected' | 'completed'

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          name: string
          email: string
          role: Role
          created_at: string
        }
        Insert: Partial<Database['public']['Tables']['users']['Row']> & { id: string; name: string; email: string; role: Role }
        Update: Partial<Database['public']['Tables']['users']['Row']>
      }
      departments: {
        Row: { id: string; name: string; description: string | null; created_at: string }
        Insert: Partial<Database['public']['Tables']['departments']['Row']> & { name: string }
        Update: Partial<Database['public']['Tables']['departments']['Row']>
      }
      trainer_departments: {
        Row: { trainer_id: string; department_id: string }
        Insert: Database['public']['Tables']['trainer_departments']['Row']
        Update: Partial<Database['public']['Tables']['trainer_departments']['Row']>
      }
      faculty_profiles: {
        Row: { id: string; user_id: string; department_id: string | null; designation: string | null }
        Insert: Partial<Database['public']['Tables']['faculty_profiles']['Row']> & { id: string; user_id: string }
        Update: Partial<Database['public']['Tables']['faculty_profiles']['Row']>
      }
      pedagogies: {
        Row: {
          id: string
          name: string
          description: string
          general_guidance: string | null
          classroom_example: string | null
          quick_plan: string | null
          created_at: string
        }
        Insert: Partial<Database['public']['Tables']['pedagogies']['Row']> & { name: string; description: string }
        Update: Partial<Database['public']['Tables']['pedagogies']['Row']>
      }
      pedagogy_department_mapping: {
        Row: { id: string; pedagogy_id: string; department_id: string; fit_type: 'strong' | 'also_consider'; reason: string }
        Insert: Partial<Database['public']['Tables']['pedagogy_department_mapping']['Row']> & { pedagogy_id: string; department_id: string; fit_type: 'strong' | 'also_consider'; reason: string }
        Update: Partial<Database['public']['Tables']['pedagogy_department_mapping']['Row']>
      }
      pedagogy_steps: {
        Row: { id: string; pedagogy_id: string; step_number: number; title: string; description: string }
        Insert: Partial<Database['public']['Tables']['pedagogy_steps']['Row']> & { pedagogy_id: string; step_number: number; title: string; description: string }
        Update: Partial<Database['public']['Tables']['pedagogy_steps']['Row']>
      }
      assessments: {
        Row: {
          id: string
          name: string
          description: string
          measures: string | null
          when_to_use: string | null
          how_to_conduct: string | null
          rubric_criteria: string | null
          evidence_produced: string | null
          created_at: string
        }
        Insert: Partial<Database['public']['Tables']['assessments']['Row']> & { name: string; description: string }
        Update: Partial<Database['public']['Tables']['assessments']['Row']>
      }
      activities: {
        Row: {
          id: string
          faculty_id: string
          trainer_id: string | null
          department_id: string | null
          course_code: string | null
          course_name: string | null
          semester: string | null
          class_name: string | null
          num_students: number | null
          activity_date: string
          title: string
          pedagogy_id: string | null
          assessment_id: string | null
          thinking_level: ThinkingLevel | null
          description: string | null
          learning_outcome: string | null
          implementation: string | null
          assessment_notes: string | null
          student_outcome: string | null
          reflection: string | null
          status: ActivityStatus
          created_at: string
          updated_at: string
        }
        Insert: Partial<Database['public']['Tables']['activities']['Row']> & { faculty_id: string; activity_date: string; title: string }
        Update: Partial<Database['public']['Tables']['activities']['Row']>
      }
      evidence: {
        Row: { id: string; activity_id: string; file_name: string; storage_path: string; file_type: string; uploaded_at: string }
        Insert: Partial<Database['public']['Tables']['evidence']['Row']> & { activity_id: string; file_name: string; storage_path: string; file_type: string }
        Update: Partial<Database['public']['Tables']['evidence']['Row']>
      }
      trainer_notes: {
        Row: {
          id: string
          trainer_id: string
          faculty_id: string
          activity_id: string | null
          existing_practice: string | null
          suggested_pedagogy: string | null
          suggested_assessment: string | null
          hots_opportunity: string | null
          evidence_available: string | null
          evidence_needed: string | null
          notes: string | null
          follow_up: string | null
          follow_up_date: string | null
          status: TrainerStatus
          created_at: string
          updated_at: string
        }
        Insert: Partial<Database['public']['Tables']['trainer_notes']['Row']> & { trainer_id: string; faculty_id: string }
        Update: Partial<Database['public']['Tables']['trainer_notes']['Row']>
      }
    }
  }
}
