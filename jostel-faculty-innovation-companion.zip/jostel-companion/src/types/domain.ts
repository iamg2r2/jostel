import type { Database } from './database'

export type UserRow = Database['public']['Tables']['users']['Row']
export type Department = Database['public']['Tables']['departments']['Row']
export type FacultyProfile = Database['public']['Tables']['faculty_profiles']['Row']
export type Pedagogy = Database['public']['Tables']['pedagogies']['Row']
export type PedagogyMapping = Database['public']['Tables']['pedagogy_department_mapping']['Row']
export type PedagogyStep = Database['public']['Tables']['pedagogy_steps']['Row']
export type Assessment = Database['public']['Tables']['assessments']['Row']
export type Activity = Database['public']['Tables']['activities']['Row']
export type Evidence = Database['public']['Tables']['evidence']['Row']
export type TrainerNote = Database['public']['Tables']['trainer_notes']['Row']

export interface ThinkingVerbSet {
  level: 'LOTS' | 'MOTS' | 'HOTS'
  label: string
  focus: string
  groups: { name: string; verbs: string[] }[]
}
