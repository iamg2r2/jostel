import { useEffect, useState } from 'react'
import AppShell from '../../components/AppShell'
import { supabase } from '../../lib/supabase'
import type { Assessment } from '../../types/domain'
import { suggestAssessmentRedesign } from '../../data/thinkingLevels'

const WHAT_OPTIONS = [
  'Knowledge', 'Application', 'Analysis', 'Evaluation', 'Creation',
  'Practical skill', 'Communication', 'Collaboration', 'Reflection',
]

const MEASURE_MAP: Record<string, string[]> = {
  Knowledge: ['Quiz-Based Assessment', 'Viva'],
  Application: ['Performance Task', 'Practical Demonstration', 'Simulation'],
  Analysis: ['Case Analysis', 'Concept Map Assessment'],
  Evaluation: ['Case Analysis', 'Debate', 'Peer Assessment'],
  Creation: ['Project', 'Portfolio'],
  'Practical skill': ['Practical Demonstration', 'Performance Task'],
  Communication: ['Presentation', 'Debate', 'Viva'],
  Collaboration: ['Peer Assessment', 'Project'],
  Reflection: ['Reflective Journal', 'Self Assessment'],
}

export default function AssessmentHelper() {
  const [assessments, setAssessments] = useState<Assessment[]>([])
  const [selectedGoal, setSelectedGoal] = useState('')
  const [expanded, setExpanded] = useState<string | null>(null)
  const [question, setQuestion] = useState('')
  const [redesign, setRedesign] = useState<ReturnType<typeof suggestAssessmentRedesign> | null>(null)

  useEffect(() => {
    supabase.from('assessments').select('*').order('name').then(({ data }) => setAssessments(data ?? []))
  }, [])

  const suggested = selectedGoal
    ? assessments.filter((a) => (MEASURE_MAP[selectedGoal] ?? []).includes(a.name))
    : assessments

  return (
    <AppShell>
      <div className="max-w-2xl space-y-10">
        <div>
          <h1 className="text-3xl mb-4">Assessment help</h1>
          <p className="field-label">What are you trying to assess?</p>
          <div className="flex flex-wrap gap-2 mb-6">
            <button
              onClick={() => setSelectedGoal('')}
              className={`pill border ${!selectedGoal ? 'bg-azure-500 text-white border-azure-500' : 'border-azure-200 text-ink-700'}`}
            >
              All
            </button>
            {WHAT_OPTIONS.map((o) => (
              <button
                key={o}
                onClick={() => setSelectedGoal(o)}
                className={`pill border ${selectedGoal === o ? 'bg-azure-500 text-white border-azure-500' : 'border-azure-200 text-ink-700'}`}
              >
                {o}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {suggested.map((a) => (
              <div key={a.id} className="surface-card">
                <button className="w-full text-left flex items-center justify-between" onClick={() => setExpanded(expanded === a.id ? null : a.id)}>
                  <p className="font-display text-lg text-ink-900">{a.name}</p>
                  <span className="text-azure-600 text-sm">{expanded === a.id ? 'Hide details' : 'Show details'}</span>
                </button>
                {expanded === a.id && (
                  <div className="mt-3 space-y-2 text-sm text-ink-700">
                    {a.measures && <p><span className="font-medium text-ink-900">Measures: </span>{a.measures}</p>}
                    {a.when_to_use && <p><span className="font-medium text-ink-900">When to use: </span>{a.when_to_use}</p>}
                    {a.how_to_conduct && <p><span className="font-medium text-ink-900">How to conduct: </span>{a.how_to_conduct}</p>}
                    {a.rubric_criteria && <p><span className="font-medium text-ink-900">Suggested rubric criteria: </span>{a.rubric_criteria}</p>}
                    {a.evidence_produced && <p><span className="font-medium text-ink-900">Evidence produced: </span>{a.evidence_produced}</p>}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <section className="surface-card">
          <h2 className="text-xl mb-1">Improve my assessment</h2>
          <p className="text-sm text-ink-700 mb-4">Enter a question or task you already use, and see it reframed at a higher thinking level.</p>
          <label className="field-label" htmlFor="q">Current question or task</label>
          <textarea
            id="q"
            className="field-input mb-3"
            rows={2}
            placeholder='e.g. "5-mark question: Explain cloud computing."'
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
          />
          <button className="btn-primary" onClick={() => setRedesign(suggestAssessmentRedesign(question))} disabled={!question.trim()}>
            Suggest a redesign
          </button>

          {redesign && (
            <div className="mt-6 space-y-3 text-ink-700">
              <p>{redesign.current}</p>
              <p><span className="font-medium text-ink-900">Possible MOTS version — </span>{redesign.mots.replace('Possible MOTS version: ', '')}</p>
              <p><span className="font-medium text-ink-900">Possible HOTS version — </span>{redesign.hots.replace('Possible HOTS version: ', '')}</p>
            </div>
          )}
        </section>
      </div>
    </AppShell>
  )
}
