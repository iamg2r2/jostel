import { useNavigate } from 'react-router-dom'
import AppShell from '../../components/AppShell'
import { useAuth } from '../../contexts/AuthContext'

const ACTIONS = [
  { title: 'Find a teaching approach', desc: 'Explore pedagogies suited to your department and goal.', to: '/faculty/pedagogy-explorer' },
  { title: 'Improve an assessment', desc: 'Get help choosing or redesigning an assessment.', to: '/faculty/assessment-helper' },
  { title: 'Explore LOTS / MOTS / HOTS', desc: 'Understand thinking levels and turn an activity into HOTS.', to: '/faculty/thinking-levels' },
  { title: 'Create an activity report', desc: 'Document a classroom activity and generate a PDF report.', to: '/faculty/activities/new' },
  { title: 'My saved activities', desc: 'Continue drafts or review past reports.', to: '/faculty/activities' },
]

function greeting() {
  const h = new Date().getHours()
  if (h < 12) return 'Good morning'
  if (h < 17) return 'Good afternoon'
  return 'Good evening'
}

export default function FacultyHome() {
  const navigate = useNavigate()
  const { profile } = useAuth()
  const firstName = profile?.name?.split(' ')[0] ?? 'there'

  return (
    <AppShell>
      <div className="max-w-3xl">
        <h1 className="text-3xl mb-1">{greeting()}, {firstName}</h1>
        <p className="text-ink-700 mb-8">What would you like help with?</p>

        <div className="grid sm:grid-cols-2 gap-4">
          {ACTIONS.map((a) => (
            <button key={a.to} onClick={() => navigate(a.to)} className="surface-card text-left hover:border-azure-300 transition">
              <p className="text-lg font-display text-ink-900 mb-1">{a.title}</p>
              <p className="text-sm text-ink-700">{a.desc}</p>
            </button>
          ))}
        </div>
      </div>
    </AppShell>
  )
}
