import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useParams, useSearchParams } from 'react-router-dom'
import AppShell from '../../components/AppShell'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import type { Activity, Assessment, Department, Evidence, Pedagogy } from '../../types/domain'
import type { ThinkingLevel } from '../../types/database'
import { saveDraft, loadDraft, clearDraft } from '../../lib/drafts'
import { generateActivityReportPdf } from '../../lib/pdf'
import { EVIDENCE_GUIDANCE, EVIDENCE_READINESS_CHECKLIST } from '../../data/evidence'

type FormState = Partial<Activity>

const EMPTY: FormState = {
  course_code: '', course_name: '', semester: '', class_name: '', num_students: undefined,
  activity_date: new Date().toISOString().slice(0, 10), title: '',
  department_id: undefined, pedagogy_id: undefined, assessment_id: undefined,
  thinking_level: undefined, description: '', learning_outcome: '', implementation: '',
  assessment_notes: '', student_outcome: '', reflection: '', status: 'draft',
}

export default function ActivityForm() {
  const { id } = useParams()
  const [params] = useSearchParams()
  const navigate = useNavigate()
  const { session, profile } = useAuth()
  const isNew = !id || id === 'new'
  const draftKey = isNew ? 'new-activity' : `activity-${id}`

  const [form, setForm] = useState<FormState>(EMPTY)
  const [departments, setDepartments] = useState<Department[]>([])
  const [pedagogies, setPedagogies] = useState<Pedagogy[]>([])
  const [assessments, setAssessments] = useState<Assessment[]>([])
  const [evidenceFiles, setEvidenceFiles] = useState<Evidence[]>([])
  const [uploading, setUploading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [savedAt, setSavedAt] = useState<Date | null>(null)
  const [activityId, setActivityId] = useState<string | null>(isNew ? null : id!)
  const [loading, setLoading] = useState(!isNew)

  useEffect(() => {
    supabase.from('departments').select('*').order('name').then(({ data }) => setDepartments(data ?? []))
    supabase.from('pedagogies').select('*').order('name').then(({ data }) => setPedagogies(data ?? []))
    supabase.from('assessments').select('*').order('name').then(({ data }) => setAssessments(data ?? []))
  }, [])

  useEffect(() => {
    const pedagogyParam = params.get('pedagogy')
    if (isNew && pedagogyParam) {
      setForm((f) => ({ ...f, pedagogy_id: pedagogyParam }))
    }
  }, [isNew, params])

  useEffect(() => {
    if (isNew) {
      const draft = loadDraft<FormState>(draftKey)
      if (draft) setForm({ ...EMPTY, ...draft })
      return
    }
    supabase.from('activities').select('*').eq('id', id).single().then(({ data }) => {
      if (data) setForm(data)
      setLoading(false)
    })
    supabase.from('evidence').select('*').eq('activity_id', id).order('uploaded_at').then(({ data }) => setEvidenceFiles(data ?? []))
  }, [id, isNew])

  useEffect(() => {
    const timer = setTimeout(() => saveDraft(draftKey, form), 600)
    return () => clearTimeout(timer)
  }, [form, draftKey])

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  async function handleSave(status: 'draft' | 'in_progress' | 'completed') {
    if (!session) return
    setSaving(true)
    const payload = { ...form, faculty_id: session.user.id, status }
    let result
    if (activityId) {
      result = await supabase.from('activities').update(payload).eq('id', activityId).select().single()
    } else {
      result = await supabase.from('activities').insert(payload).select().single()
    }
    setSaving(false)
    if (result.error) {
      alert('Could not save right now. Your work is kept as a draft on this device and will not be lost — try again once you\'re back online.')
      return
    }
    setActivityId(result.data.id)
    setForm(result.data)
    clearDraft(draftKey)
    setSavedAt(new Date())
    if (isNew) navigate(`/faculty/activities/${result.data.id}`, { replace: true })
  }

  async function handleUpload(files: FileList | null) {
    if (!files || files.length === 0) return
    if (!activityId) {
      alert('Save the activity once (even as a draft) before attaching evidence — this keeps files linked correctly.')
      return
    }
    setUploading(true)
    for (const file of Array.from(files)) {
      const path = `${activityId}/${Date.now()}-${file.name}`
      const { error: uploadError } = await supabase.storage.from('evidence').upload(path, file)
      if (uploadError) {
        alert(`Could not upload ${file.name}: ${uploadError.message}`)
        continue
      }
      const { data } = await supabase
        .from('evidence')
        .insert({ activity_id: activityId, file_name: file.name, storage_path: path, file_type: file.type })
        .select()
        .single()
      if (data) setEvidenceFiles((prev) => [...prev, data])
    }
    setUploading(false)
  }

  async function handleRemoveEvidence(ev: Evidence) {
    await supabase.storage.from('evidence').remove([ev.storage_path])
    await supabase.from('evidence').delete().eq('id', ev.id)
    setEvidenceFiles((prev) => prev.filter((e) => e.id !== ev.id))
  }

  const readinessCount = useMemo(() => {
    let count = 0
    if (form.learning_outcome) count++
    if (form.implementation) count++
    if (evidenceFiles.length > 0) count++
    if (evidenceFiles.some((e) => e.file_type.startsWith('image') || e.file_type.includes('pdf'))) count++
    if (form.assessment_id || form.assessment_notes) count++
    // "feedback" folded into student outcome/reflection presence
    if (form.reflection) count++
    if (form.student_outcome) count++
    if (form.description) count++
    return Math.min(count, EVIDENCE_READINESS_CHECKLIST.length)
  }, [form, evidenceFiles])

  function handleGeneratePdf() {
    if (!activityId || !profile) return
    const departmentName = departments.find((d) => d.id === form.department_id)?.name
    const pedagogyName = pedagogies.find((p) => p.id === form.pedagogy_id)?.name
    const assessmentName = assessments.find((a) => a.id === form.assessment_id)?.name
    generateActivityReportPdf({
      activity: form as Activity,
      facultyName: profile.name,
      departmentName,
      pedagogyName,
      assessmentName,
      evidence: evidenceFiles,
    })
  }

  if (loading) return <AppShell><p className="text-ink-700">Loading…</p></AppShell>

  return (
    <AppShell>
      <div className="max-w-2xl">
        <h1 className="text-3xl mb-1">{isNew ? 'Create activity report' : 'Edit activity'}</h1>
        <p className="text-sm text-ink-700 mb-8">
          {savedAt ? `Saved ${savedAt.toLocaleTimeString()}` : 'Your work saves automatically as a draft.'}
        </p>

        <section className="surface-card mb-6">
          <h2 className="text-xl mb-4">Course information</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="field-label">Course code *</label>
              <input className="field-input" value={form.course_code ?? ''} onChange={(e) => update('course_code', e.target.value)} />
            </div>
            <div>
              <label className="field-label">Course name *</label>
              <input className="field-input" value={form.course_name ?? ''} onChange={(e) => update('course_name', e.target.value)} />
            </div>
            <div>
              <label className="field-label">Department</label>
              <select className="field-input" value={form.department_id ?? ''} onChange={(e) => update('department_id', e.target.value)}>
                <option value="">Select…</option>
                {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select>
            </div>
            <div>
              <label className="field-label">Semester</label>
              <input className="field-input" value={form.semester ?? ''} onChange={(e) => update('semester', e.target.value)} />
            </div>
            <div>
              <label className="field-label">Class</label>
              <input className="field-input" value={form.class_name ?? ''} onChange={(e) => update('class_name', e.target.value)} />
            </div>
            <div>
              <label className="field-label">Number of students</label>
              <input type="number" className="field-input" value={form.num_students ?? ''} onChange={(e) => update('num_students', e.target.value ? Number(e.target.value) : undefined)} />
            </div>
          </div>
        </section>

        <section className="surface-card mb-6">
          <h2 className="text-xl mb-4">Activity</h2>
          <div className="space-y-4">
            <div>
              <label className="field-label">Activity title *</label>
              <input className="field-input" value={form.title ?? ''} onChange={(e) => update('title', e.target.value)} />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="field-label">Activity date *</label>
                <input type="date" className="field-input" value={form.activity_date ?? ''} onChange={(e) => update('activity_date', e.target.value)} />
              </div>
              <div>
                <label className="field-label">Thinking level</label>
                <select className="field-input" value={form.thinking_level ?? ''} onChange={(e) => update('thinking_level', (e.target.value || undefined) as ThinkingLevel | undefined)}>
                  <option value="">Select…</option>
                  <option value="LOTS">LOTS</option>
                  <option value="MOTS">MOTS</option>
                  <option value="HOTS">HOTS</option>
                </select>
              </div>
            </div>
            <div>
              <label className="field-label">Pedagogical approach</label>
              <select className="field-input" value={form.pedagogy_id ?? ''} onChange={(e) => update('pedagogy_id', e.target.value)}>
                <option value="">Select…</option>
                {pedagogies.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
              </select>
            </div>
            <div>
              <label className="field-label">Assessment approach</label>
              <select className="field-input" value={form.assessment_id ?? ''} onChange={(e) => update('assessment_id', e.target.value)}>
                <option value="">Select…</option>
                {assessments.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
              </select>
            </div>
          </div>
        </section>

        <section className="surface-card mb-6 space-y-4">
          <div>
            <label className="field-label">What did you do?</label>
            <textarea className="field-input" rows={3} value={form.description ?? ''} onChange={(e) => update('description', e.target.value)} />
          </div>
          <div>
            <label className="field-label">What were students expected to learn/do?</label>
            <textarea className="field-input" rows={2} value={form.learning_outcome ?? ''} onChange={(e) => update('learning_outcome', e.target.value)} />
          </div>
          <div>
            <label className="field-label">How was the activity conducted?</label>
            <textarea className="field-input" rows={3} value={form.implementation ?? ''} onChange={(e) => update('implementation', e.target.value)} />
          </div>
          <div>
            <label className="field-label">How was student learning assessed?</label>
            <textarea className="field-input" rows={2} value={form.assessment_notes ?? ''} onChange={(e) => update('assessment_notes', e.target.value)} />
          </div>
          <div>
            <label className="field-label">What did students demonstrate, produce or improve?</label>
            <textarea className="field-input" rows={2} value={form.student_outcome ?? ''} onChange={(e) => update('student_outcome', e.target.value)} />
          </div>
          <div>
            <label className="field-label">Faculty reflection — what worked? What would you change?</label>
            <textarea className="field-input" rows={3} value={form.reflection ?? ''} onChange={(e) => update('reflection', e.target.value)} />
          </div>
        </section>

        <section className="surface-card mb-6">
          <h2 className="text-xl mb-1">Evidence</h2>
          <p className="text-sm text-ink-700 mb-4">{EVIDENCE_GUIDANCE.message}</p>

          <input
            type="file"
            multiple
            accept=".jpg,.jpeg,.png,.webp,.pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx"
            onChange={(e) => handleUpload(e.target.files)}
            className="mb-4 text-sm"
            disabled={uploading}
          />

          <ul className="space-y-1.5 mb-4">
            {evidenceFiles.map((ev) => (
              <li key={ev.id} className="flex items-center justify-between text-sm bg-azure-50 rounded-lg px-3 py-2">
                <span>📎 {ev.file_name}</span>
                <button onClick={() => handleRemoveEvidence(ev)} className="text-ink-700/60 hover:text-tangerine-600">Remove</button>
              </li>
            ))}
            {evidenceFiles.length === 0 && <li className="text-sm text-ink-700/60">No files uploaded yet.</li>}
          </ul>

          <details className="text-sm text-ink-700">
            <summary className="cursor-pointer text-azure-600 font-medium">What evidence should I keep?</summary>
            <div className="mt-3 grid sm:grid-cols-3 gap-3">
              {EVIDENCE_GUIDANCE.categories.map((c) => (
                <div key={c.phase}>
                  <p className="font-medium text-ink-900 mb-1">{c.phase}</p>
                  <ul className="list-disc list-inside space-y-0.5">
                    {c.items.map((i) => <li key={i}>{i}</li>)}
                  </ul>
                </div>
              ))}
            </div>
          </details>

          <div className="mt-4 pt-4 border-t border-azure-100">
            <p className="text-sm font-medium text-ink-900 mb-1">
              Evidence readiness — {readinessCount} of {EVIDENCE_READINESS_CHECKLIST.length} useful layers
            </p>
            <div className="w-full h-2 bg-azure-50 rounded-full overflow-hidden">
              <div className="h-full bg-tangerine-500" style={{ width: `${(readinessCount / EVIDENCE_READINESS_CHECKLIST.length) * 100}%` }} />
            </div>
          </div>
        </section>

        <div className="flex flex-wrap gap-3">
          <button className="btn-primary" disabled={saving} onClick={() => handleSave('completed')}>
            {saving ? 'Saving…' : 'Save activity'}
          </button>
          <button className="btn-secondary" disabled={saving} onClick={() => handleSave('draft')}>
            Save as draft
          </button>
          {activityId && (
            <button className="btn-tangerine" onClick={handleGeneratePdf}>
              Generate PDF
            </button>
          )}
          <button className="text-sm text-ink-700/60 hover:text-ink-700 ml-auto" onClick={() => navigate('/faculty/activities')}>
            Back to my activities
          </button>
        </div>
      </div>
    </AppShell>
  )
}
