import { useState } from 'react'
import AppShell from '../../components/AppShell'
import { THINKING_LEVELS, THINKING_LEVEL_MESSAGE, transformToThinkingLevels } from '../../data/thinkingLevels'

export default function ThinkingLevels() {
  const [input, setInput] = useState('')
  const [result, setResult] = useState<ReturnType<typeof transformToThinkingLevels> | null>(null)

  return (
    <AppShell>
      <div className="max-w-2xl">
        <h1 className="text-3xl mb-4">LOTS, MOTS and HOTS</h1>

        <div className="surface-card mb-8 bg-tangerine-50/40 border-tangerine-100">
          <p className="text-ink-800">{THINKING_LEVEL_MESSAGE}</p>
        </div>

        <div className="space-y-6 mb-10">
          {THINKING_LEVELS.map((level) => (
            <section key={level.level}>
              <h2 className="text-xl mb-1">{level.label}</h2>
              <p className="text-sm text-ink-700 mb-3">{level.focus}</p>
              <div className="grid sm:grid-cols-3 gap-3">
                {level.groups.map((g) => (
                  <div key={g.name} className="surface-card !p-4">
                    <p className="text-sm font-medium text-ink-900 mb-2">{g.name}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {g.verbs.map((v) => (
                        <span key={v} className="pill bg-azure-50 text-azure-700">{v}</span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>

        <section className="surface-card">
          <h2 className="text-xl mb-1">Turn this into HOTS</h2>
          <p className="text-sm text-ink-700 mb-4">
            Describe an activity you're already doing, and see it rewritten at each thinking level.
          </p>
          <label className="field-label" htmlFor="activity">Your current activity</label>
          <textarea
            id="activity"
            className="field-input mb-3"
            rows={3}
            placeholder='e.g. "Students read the chapter and answer 10 questions."'
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
          <button className="btn-primary" onClick={() => setResult(transformToThinkingLevels(input))} disabled={!input.trim()}>
            Show me the levels
          </button>

          {result && (
            <div className="mt-6 space-y-4">
              <div>
                <p className="pill bg-azure-50 text-azure-700 mb-1">LOTS version</p>
                <p className="text-ink-700">{result.lots}</p>
              </div>
              <div>
                <p className="pill bg-azure-100 text-azure-800 mb-1">MOTS version</p>
                <p className="text-ink-700">{result.mots}</p>
              </div>
              <div>
                <p className="pill bg-tangerine-100 text-tangerine-800 mb-1">HOTS version</p>
                <p className="text-ink-700">{result.hots}</p>
              </div>
              <p className="text-xs text-ink-700/60">
                These are starting points to adapt to your actual content — not a final worksheet.
              </p>
            </div>
          )}
        </section>
      </div>
    </AppShell>
  )
}
