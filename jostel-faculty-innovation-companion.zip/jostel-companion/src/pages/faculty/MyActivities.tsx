import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import AppShell from '../../components/AppShell'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import type { Activity } from '../../types/domain'

const STATUS_LABEL: Record<string, string> = {
  draft: 'Draft', in_progress: 'In progress', completed: 'Completed',
}
const STATUS_CLASS: Record<string, string> = {
  draft: 'bg-azure-50 text-azure-700',
  in_progress: 'bg-tangerine-50 text-tangerine-700',
  completed: 'bg-green-50 text-green-700',
}

export default function MyActivities() {
  const { session } = useAuth()
  const [activities, setActivities] = useState<Activity[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!session) return
    supabase
      .from('activities')
      .select('*')
      .eq('faculty_id', session.user.id)
      .order('updated_at', { ascending: false })
      .then(({ data }) => {
        setActivities(data ?? [])
        setLoading(false)
      })
  }, [session])

  return (
    <AppShell>
      <div className="max-w-2xl">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl">My saved activities</h1>
          <Link to="/faculty/activities/new" className="btn-primary !px-5 !py-2.5 text-sm">New activity</Link>
        </div>

        {loading && <p className="text-ink-700">Loading…</p>}
        {!loading && activities.length === 0 && (
          <div className="surface-card text-center">
            <p className="text-ink-700 mb-3">You haven't created an activity report yet.</p>
            <Link to="/faculty/activities/new" className="btn-primary !inline-flex">Create your first one</Link>
          </div>
        )}

        <ul className="space-y-3">
          {activities.map((a) => (
            <li key={a.id}>
              <Link to={`/faculty/activities/${a.id}`} className="surface-card hover:border-azure-300 transition flex items-center justify-between block">
                <div>
                  <p className="font-display text-lg text-ink-900">{a.title || 'Untitled activity'}</p>
                  <p className="text-sm text-ink-700">{a.course_name || 'No course set'} · {a.activity_date}</p>
                </div>
                <span className={`pill ${STATUS_CLASS[a.status]}`}>{STATUS_LABEL[a.status]}</span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </AppShell>
  )
}
