import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import AppShell from '../../components/AppShell'
import { supabase } from '../../lib/supabase'
import type { Pedagogy, PedagogyStep } from '../../types/domain'

export default function PedagogyDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [pedagogy, setPedagogy] = useState<Pedagogy | null>(null)
  const [steps, setSteps] = useState<PedagogyStep[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!id) return
    Promise.all([
      supabase.from('pedagogies').select('*').eq('id', id).single(),
      supabase.from('pedagogy_steps').select('*').eq('pedagogy_id', id).order('step_number'),
    ]).then(([p, s]) => {
      setPedagogy(p.data ?? null)
      setSteps(s.data ?? [])
      setLoading(false)
    })
  }, [id])

  if (loading) return <AppShell><p className="text-ink-700">Loading…</p></AppShell>
  if (!pedagogy) return <AppShell><p className="text-ink-700">Not found.</p></AppShell>

  return (
    <AppShell>
      <div className="max-w-2xl">
        <p className="text-lg text-ink-900 font-display mb-1">{pedagogy.name}</p>
        <h1 className="text-3xl mb-6">What is it?</h1>
        <p className="text-ink-700 -mt-4 mb-8">{pedagogy.description}</p>

        {pedagogy.general_guidance && (
          <section className="mb-8">
            <h2 className="text-xl mb-2">When might it help?</h2>
            <p className="text-ink-700">{pedagogy.general_guidance}</p>
          </section>
        )}

        {pedagogy.classroom_example && (
          <section className="mb-8 surface-card">
            <h2 className="text-xl mb-2">Try this in your class</h2>
            <p className="text-ink-700 italic">{pedagogy.classroom_example}</p>
          </section>
        )}

        {steps.length > 0 && (
          <section className="mb-8">
            <h2 className="text-xl mb-3">Step by step</h2>
            <ol className="space-y-3">
              {steps.map((s) => (
                <li key={s.id} className="flex gap-3">
                  <span className="shrink-0 w-7 h-7 rounded-full bg-azure-500 text-white flex items-center justify-center text-sm font-medium">
                    {s.step_number}
                  </span>
                  <div>
                    <p className="font-medium text-ink-900">{s.title}</p>
                    <p className="text-sm text-ink-700">{s.description}</p>
                  </div>
                </li>
              ))}
            </ol>
          </section>
        )}

        {pedagogy.quick_plan && (
          <section className="mb-8 surface-card bg-tangerine-50/40 border-tangerine-100">
            <h2 className="text-xl mb-2">Try it in your next class</h2>
            <p className="text-sm text-ink-700/70 mb-2">A rough 60-minute version — adjust to your actual class length.</p>
            <p className="text-ink-700">{pedagogy.quick_plan}</p>
          </section>
        )}

        <section className="mb-10 surface-card">
          <h2 className="text-xl mb-2">What evidence should I keep?</h2>
          <p className="text-sm text-ink-700 mb-2">
            See the Evidence guide on your activity report for a full checklist — in short: keep what
            genuinely exists (plans, participation, artefacts, feedback), and don't manufacture documentation
            just to make the activity look more innovative.
          </p>
        </section>

        <div className="flex gap-3">
          <button className="btn-primary" onClick={() => navigate(`/faculty/activities/new?pedagogy=${pedagogy.id}`)}>
            Use this in an activity report
          </button>
          <button className="btn-secondary" onClick={() => navigate(-1)}>Back</button>
        </div>
      </div>
    </AppShell>
  )
}
