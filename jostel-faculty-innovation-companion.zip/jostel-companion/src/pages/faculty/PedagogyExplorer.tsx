import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import AppShell from '../../components/AppShell'
import { supabase } from '../../lib/supabase'
import type { Department, Pedagogy } from '../../types/domain'

interface MappedPedagogy {
  pedagogy: Pedagogy
  fit_type: 'strong' | 'also_consider'
  reason: string
}

const GOALS = ['Remember / Understand', 'Apply', 'Analyse', 'Evaluate', 'Create']

export default function PedagogyExplorer() {
  const [departments, setDepartments] = useState<Department[]>([])
  const [allPedagogies, setAllPedagogies] = useState<Pedagogy[]>([])
  const [departmentId, setDepartmentId] = useState<string>('')
  const [goal, setGoal] = useState<string>('')
  const [mapped, setMapped] = useState<MappedPedagogy[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    supabase.from('departments').select('*').order('name').then(({ data }) => setDepartments(data ?? []))
    supabase.from('pedagogies').select('*').order('name').then(({ data }) => setAllPedagogies(data ?? []))
  }, [])

  useEffect(() => {
    if (!departmentId) {
      setMapped([])
      return
    }
    setLoading(true)
    supabase
      .from('pedagogy_department_mapping')
      .select('fit_type, reason, pedagogies(*)')
      .eq('department_id', departmentId)
      .then(({ data }) => {
        const rows = (data ?? [])
          .filter((r: any) => r.pedagogies)
          .map((r: any) => ({ pedagogy: r.pedagogies as Pedagogy, fit_type: r.fit_type, reason: r.reason }))
        rows.sort((a: MappedPedagogy, b: MappedPedagogy) => (a.fit_type === b.fit_type ? 0 : a.fit_type === 'strong' ? -1 : 1))
        setMapped(rows)
        setLoading(false)
      })
  }, [departmentId])

  const departmentName = departments.find((d) => d.id === departmentId)?.name

  return (
    <AppShell>
      <div className="max-w-3xl">
        <h1 className="text-3xl mb-2">Find a teaching approach</h1>
        <p className="text-ink-700 mb-6">
          Tell us your department and what you want students to do — we'll suggest a few approaches worth
          considering, not just one.
        </p>

        <div className="surface-card mb-8 grid sm:grid-cols-2 gap-4">
          <div>
            <label className="field-label" htmlFor="dept">Department</label>
            <select id="dept" className="field-input" value={departmentId} onChange={(e) => setDepartmentId(e.target.value)}>
              <option value="">Choose your department…</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="field-label" htmlFor="goal">What should students do? (optional)</label>
            <select id="goal" className="field-input" value={goal} onChange={(e) => setGoal(e.target.value)}>
              <option value="">Any thinking level</option>
              {GOALS.map((g) => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>
          </div>
        </div>

        {!departmentId && (
          <div>
            <h2 className="text-xl mb-3">Or browse the full library</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              {allPedagogies.map((p) => (
                <Link key={p.id} to={`/faculty/pedagogy/${p.id}`} className="surface-card hover:border-azure-300 transition block">
                  <p className="font-display text-ink-900">{p.name}</p>
                  <p className="text-sm text-ink-700 line-clamp-2">{p.description}</p>
                </Link>
              ))}
            </div>
          </div>
        )}

        {departmentId && (
          <div>
            <h2 className="text-xl mb-3">Approaches for {departmentName}</h2>
            {loading && <p className="text-ink-700">Loading…</p>}
            {!loading && mapped.length === 0 && (
              <p className="text-ink-700">
                No department-specific suggestions yet — browse the{' '}
                <button className="text-azure-600 underline" onClick={() => setDepartmentId('')}>full library</button> instead.
              </p>
            )}
            <div className="space-y-3">
              {mapped.map(({ pedagogy, fit_type, reason }) => (
                <Link
                  key={pedagogy.id}
                  to={`/faculty/pedagogy/${pedagogy.id}`}
                  className="surface-card hover:border-azure-300 transition block"
                >
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-display text-lg text-ink-900">{pedagogy.name}</p>
                    <span className={`pill ${fit_type === 'strong' ? 'bg-tangerine-50 text-tangerine-700' : 'bg-azure-50 text-azure-700'}`}>
                      {fit_type === 'strong' ? 'Strong fit' : 'Also consider'}
                    </span>
                  </div>
                  <p className="text-sm text-ink-700">{reason}</p>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </AppShell>
  )
}
