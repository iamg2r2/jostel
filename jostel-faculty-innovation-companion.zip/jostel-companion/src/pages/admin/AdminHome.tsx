import { Link } from 'react-router-dom'
import AppShell from '../../components/AppShell'

const SECTIONS = [
  { title: 'Departments', desc: 'Add departments, assign trainers, link faculty.', to: '/admin/departments' },
  { title: 'Pedagogies', desc: 'Manage the pedagogy library and department fit.', to: '/admin/pedagogies' },
  { title: 'Assessments', desc: 'Manage the assessment library.', to: '/admin/assessments' },
]

export default function AdminHome() {
  return (
    <AppShell>
      <div className="max-w-2xl">
        <h1 className="text-3xl mb-6">Admin</h1>
        <div className="grid sm:grid-cols-2 gap-4">
          {SECTIONS.map((s) => (
            <Link key={s.to} to={s.to} className="surface-card hover:border-azure-300 transition">
              <p className="font-display text-lg text-ink-900 mb-1">{s.title}</p>
              <p className="text-sm text-ink-700">{s.desc}</p>
            </Link>
          ))}
        </div>
      </div>
    </AppShell>
  )
}
