import { useEffect, useState } from 'react'
import AppShell from '../../components/AppShell'
import { supabase } from '../../lib/supabase'
import type { Pedagogy } from '../../types/domain'

const EMPTY = { name: '', description: '', general_guidance: '', classroom_example: '', quick_plan: '' }

export default function AdminPedagogies() {
  const [pedagogies, setPedagogies] = useState<Pedagogy[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState(EMPTY)
  const [saving, setSaving] = useState(false)

  async function reload() {
    const { data } = await supabase.from('pedagogies').select('*').order('name')
    setPedagogies(data ?? [])
  }
  useEffect(() => { reload() }, [])

  function startEdit(p: Pedagogy) {
    setEditingId(p.id)
    setForm({
      name: p.name, description: p.description,
      general_guidance: p.general_guidance ?? '', classroom_example: p.classroom_example ?? '', quick_plan: p.quick_plan ?? '',
    })
  }
  function startNew() {
    setEditingId('new')
    setForm(EMPTY)
  }

  async function save() {
    if (!form.name.trim() || !form.description.trim()) return
    setSaving(true)
    if (editingId && editingId !== 'new') {
      await supabase.from('pedagogies').update(form).eq('id', editingId)
    } else {
      await supabase.from('pedagogies').insert(form)
    }
    setSaving(false)
    setEditingId(null)
    reload()
  }

  async function remove(id: string) {
    if (!confirm('Delete this pedagogy? Its steps and department mappings will be removed too.')) return
    await supabase.from('pedagogies').delete().eq('id', id)
    reload()
  }

  return (
    <AppShell>
      <div className="max-w-2xl">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl">Pedagogies</h1>
          <button className="btn-primary !px-5 !py-2.5 text-sm" onClick={startNew}>Add pedagogy</button>
        </div>

        {editingId && (
          <section className="surface-card mb-6 space-y-3">
            <h2 className="text-lg">{editingId === 'new' ? 'New pedagogy' : 'Edit pedagogy'}</h2>
            <div>
              <label className="field-label">Name</label>
              <input className="field-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div>
              <label className="field-label">What is it? / When might it help?</label>
              <textarea className="field-input" rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <div>
              <label className="field-label">General guidance</label>
              <textarea className="field-input" rows={2} value={form.general_guidance} onChange={(e) => setForm({ ...form, general_guidance: e.target.value })} />
            </div>
            <div>
              <label className="field-label">Classroom example</label>
              <textarea className="field-input" rows={2} value={form.classroom_example} onChange={(e) => setForm({ ...form, classroom_example: e.target.value })} />
            </div>
            <div>
              <label className="field-label">Quick 60-minute plan</label>
              <textarea className="field-input" rows={2} value={form.quick_plan} onChange={(e) => setForm({ ...form, quick_plan: e.target.value })} />
            </div>
            <div className="flex gap-3">
              <button className="btn-primary" disabled={saving} onClick={save}>{saving ? 'Saving…' : 'Save'}</button>
              <button className="btn-secondary" onClick={() => setEditingId(null)}>Cancel</button>
            </div>
          </section>
        )}

        <div className="space-y-3">
          {pedagogies.map((p) => (
            <div key={p.id} className="surface-card flex items-center justify-between">
              <div>
                <p className="font-display text-ink-900">{p.name}</p>
                <p className="text-sm text-ink-700 line-clamp-1">{p.description}</p>
              </div>
              <div className="flex gap-3 shrink-0 ml-4">
                <button className="text-sm text-azure-600" onClick={() => startEdit(p)}>Edit</button>
                <button className="text-sm text-ink-700/60 hover:text-tangerine-600" onClick={() => remove(p.id)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  )
}
