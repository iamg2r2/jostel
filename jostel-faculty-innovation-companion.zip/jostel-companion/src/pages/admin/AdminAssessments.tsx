import { useEffect, useState } from 'react'
import AppShell from '../../components/AppShell'
import { supabase } from '../../lib/supabase'
import type { Assessment } from '../../types/domain'

const EMPTY = { name: '', description: '', measures: '', when_to_use: '', how_to_conduct: '', rubric_criteria: '', evidence_produced: '' }

export default function AdminAssessments() {
  const [assessments, setAssessments] = useState<Assessment[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState(EMPTY)
  const [saving, setSaving] = useState(false)

  async function reload() {
    const { data } = await supabase.from('assessments').select('*').order('name')
    setAssessments(data ?? [])
  }
  useEffect(() => { reload() }, [])

  function startEdit(a: Assessment) {
    setEditingId(a.id)
    setForm({
      name: a.name, description: a.description,
      measures: a.measures ?? '', when_to_use: a.when_to_use ?? '', how_to_conduct: a.how_to_conduct ?? '',
      rubric_criteria: a.rubric_criteria ?? '', evidence_produced: a.evidence_produced ?? '',
    })
  }
  function startNew() { setEditingId('new'); setForm(EMPTY) }

  async function save() {
    if (!form.name.trim() || !form.description.trim()) return
    setSaving(true)
    if (editingId && editingId !== 'new') {
      await supabase.from('assessments').update(form).eq('id', editingId)
    } else {
      await supabase.from('assessments').insert(form)
    }
    setSaving(false)
    setEditingId(null)
    reload()
  }

  async function remove(id: string) {
    if (!confirm('Delete this assessment approach?')) return
    await supabase.from('assessments').delete().eq('id', id)
    reload()
  }

  return (
    <AppShell>
      <div className="max-w-2xl">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl">Assessments</h1>
          <button className="btn-primary !px-5 !py-2.5 text-sm" onClick={startNew}>Add assessment</button>
        </div>

        {editingId && (
          <section className="surface-card mb-6 space-y-3">
            <h2 className="text-lg">{editingId === 'new' ? 'New assessment' : 'Edit assessment'}</h2>
            {([
              ['name', 'Name'], ['description', 'Description'], ['measures', 'What it measures'],
              ['when_to_use', 'When to use'], ['how_to_conduct', 'How to conduct'],
              ['rubric_criteria', 'Suggested rubric criteria'], ['evidence_produced', 'Evidence produced'],
            ] as const).map(([key, label]) => (
              <div key={key}>
                <label className="field-label">{label}</label>
                <textarea className="field-input" rows={key === 'name' ? 1 : 2} value={(form as any)[key]} onChange={(e) => setForm({ ...form, [key]: e.target.value })} />
              </div>
            ))}
            <div className="flex gap-3">
              <button className="btn-primary" disabled={saving} onClick={save}>{saving ? 'Saving…' : 'Save'}</button>
              <button className="btn-secondary" onClick={() => setEditingId(null)}>Cancel</button>
            </div>
          </section>
        )}

        <div className="space-y-3">
          {assessments.map((a) => (
            <div key={a.id} className="surface-card flex items-center justify-between">
              <div>
                <p className="font-display text-ink-900">{a.name}</p>
                <p className="text-sm text-ink-700 line-clamp-1">{a.description}</p>
              </div>
              <div className="flex gap-3 shrink-0 ml-4">
                <button className="text-sm text-azure-600" onClick={() => startEdit(a)}>Edit</button>
                <button className="text-sm text-ink-700/60 hover:text-tangerine-600" onClick={() => remove(a.id)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  )
}
