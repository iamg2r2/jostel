import { useEffect, useState } from 'react'
import AppShell from '../../components/AppShell'
import { supabase } from '../../lib/supabase'
import type { Department, UserRow } from '../../types/domain'

export default function AdminDepartments() {
  const [departments, setDepartments] = useState<Department[]>([])
  const [trainers, setTrainers] = useState<UserRow[]>([])
  const [assignments, setAssignments] = useState<{ trainer_id: string; department_id: string }[]>([])
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')

  async function reload() {
    const [d, t, a] = await Promise.all([
      supabase.from('departments').select('*').order('name'),
      supabase.from('users').select('*').eq('role', 'trainer').order('name'),
      supabase.from('trainer_departments').select('*'),
    ])
    setDepartments(d.data ?? [])
    setTrainers(t.data ?? [])
    setAssignments(a.data ?? [])
  }

  useEffect(() => { reload() }, [])

  async function addDepartment() {
    if (!name.trim()) return
    await supabase.from('departments').insert({ name: name.trim(), description: description.trim() || null })
    setName('')
    setDescription('')
    reload()
  }

  async function removeDepartment(id: string) {
    if (!confirm('Remove this department? Faculty and mappings linked to it will lose that link.')) return
    await supabase.from('departments').delete().eq('id', id)
    reload()
  }

  async function toggleAssignment(trainerId: string, departmentId: string, assigned: boolean) {
    if (assigned) {
      await supabase.from('trainer_departments').delete().match({ trainer_id: trainerId, department_id: departmentId })
    } else {
      await supabase.from('trainer_departments').insert({ trainer_id: trainerId, department_id: departmentId })
    }
    reload()
  }

  return (
    <AppShell>
      <div className="max-w-3xl">
        <h1 className="text-3xl mb-6">Departments</h1>

        <section className="surface-card mb-8">
          <h2 className="text-lg mb-3">Add a department</h2>
          <div className="grid sm:grid-cols-[1fr_1fr_auto] gap-3">
            <input className="field-input" placeholder="Department name" value={name} onChange={(e) => setName(e.target.value)} />
            <input className="field-input" placeholder="Description (optional)" value={description} onChange={(e) => setDescription(e.target.value)} />
            <button className="btn-primary" onClick={addDepartment}>Add</button>
          </div>
          <p className="text-xs text-ink-700/60 mt-2">Add your college's remaining departments here — there's no limit on how many you can add.</p>
        </section>

        <section>
          <h2 className="text-lg mb-3">All departments & trainer assignment</h2>
          <div className="space-y-3">
            {departments.map((d) => (
              <div key={d.id} className="surface-card">
                <div className="flex items-center justify-between mb-3">
                  <p className="font-display text-lg text-ink-900">{d.name}</p>
                  <button onClick={() => removeDepartment(d.id)} className="text-sm text-ink-700/60 hover:text-tangerine-600">Remove</button>
                </div>
                {trainers.length === 0 ? (
                  <p className="text-sm text-ink-700/60">No trainer accounts yet.</p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {trainers.map((t) => {
                      const assigned = assignments.some((a) => a.trainer_id === t.id && a.department_id === d.id)
                      return (
                        <button
                          key={t.id}
                          onClick={() => toggleAssignment(t.id, d.id, assigned)}
                          className={`pill border ${assigned ? 'bg-azure-500 text-white border-azure-500' : 'border-azure-200 text-ink-700'}`}
                        >
                          {t.name}
                        </button>
                      )
                    })}
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      </div>
    </AppShell>
  )
}
