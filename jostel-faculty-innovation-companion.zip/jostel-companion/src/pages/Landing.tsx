import { useNavigate } from 'react-router-dom'

export default function Landing() {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen flex flex-col">
      <main className="flex-1 flex items-center justify-center px-4 py-16">
        <div className="max-w-3xl w-full text-center space-y-8">
          <div className="flex justify-center">
            <svg width="56" height="56" viewBox="0 0 64 64" aria-hidden>
              <rect width="64" height="64" rx="14" fill="#087EA4" />
              <path d="M20 18h24M20 32h24M20 46h16" stroke="#EF8A3A" strokeWidth="5" strokeLinecap="round" />
            </svg>
          </div>
          <div>
            <p className="uppercase tracking-wide text-tangerine-600 text-sm font-medium mb-2">JosTEL</p>
            <h1 className="text-4xl sm:text-5xl mb-3">Faculty Innovation Companion</h1>
            <p className="text-xl text-azure-700 font-display italic">Plan it. Try it. Capture it.</p>
          </div>
          <p className="text-ink-700 max-w-xl mx-auto text-lg">
            Discover practical teaching ideas, strengthen assessment, capture evidence and create your
            activity report — without starting from scratch.
          </p>

          <div>
            <p className="text-ink-700 font-medium mb-4">What would you like to do?</p>
            <div className="grid sm:grid-cols-2 gap-4 text-left">
              <button
                onClick={() => navigate('/login?role=faculty')}
                className="surface-card hover:border-azure-300 transition text-left"
              >
                <p className="text-lg font-display text-ink-900 mb-1">I'm Faculty</p>
                <p className="text-sm text-ink-700">
                  Help me plan and document an innovative classroom activity.
                </p>
              </button>
              <button
                onClick={() => navigate('/login?role=trainer')}
                className="surface-card hover:border-tangerine-300 transition text-left"
              >
                <p className="text-lg font-display text-ink-900 mb-1">I'm a JosTEL Trainer</p>
                <p className="text-sm text-ink-700">
                  Help me support a faculty member and document our interaction.
                </p>
              </button>
            </div>
          </div>
        </div>
      </main>
      <footer className="text-center text-xs text-ink-700/60 py-6">
        JosTEL Faculty Innovation Companion · St. Joseph's College (Autonomous), Tiruchirappalli
      </footer>
    </div>
  )
}
