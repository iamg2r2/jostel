import { useState } from 'react'
import { useNavigate, useSearchParams, Link } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { isSupabaseConfigured } from '../lib/supabase'
import ConfigNeeded from '../components/ConfigNeeded'

export default function Login() {
  const [params] = useSearchParams()
  const [mode, setMode] = useState<'signin' | 'signup'>('signin')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const { signIn, signUp } = useAuth()
  const navigate = useNavigate()

  if (!isSupabaseConfigured) return <ConfigNeeded />

  const roleHint = params.get('role') === 'trainer' ? 'JosTEL Trainer' : 'Faculty'

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setSubmitting(true)
    const result = mode === 'signin' ? await signIn(email, password) : await signUp(email, password, name)
    setSubmitting(false)
    if (result.error) {
      setError(result.error)
      return
    }
    navigate('/faculty')
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="surface-card w-full max-w-md">
        <p className="text-sm text-tangerine-600 font-medium mb-1">{roleHint}</p>
        <h1 className="text-2xl mb-1">{mode === 'signin' ? 'Welcome back' : 'Create your account'}</h1>
        <p className="text-sm text-ink-700 mb-6">
          {mode === 'signin'
            ? "Sign in to continue where you left off."
            : 'Trainer and admin access is granted by your JosTEL coordinator after sign-up.'}
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <div>
              <label className="field-label" htmlFor="name">Full name</label>
              <input id="name" className="field-input" value={name} onChange={(e) => setName(e.target.value)} required />
            </div>
          )}
          <div>
            <label className="field-label" htmlFor="email">College email</label>
            <input id="email" type="email" className="field-input" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div>
            <label className="field-label" htmlFor="password">Password</label>
            <input id="password" type="password" className="field-input" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} />
          </div>

          {error && <p className="text-sm text-red-600" role="alert">{error}</p>}

          <button type="submit" disabled={submitting} className="btn-primary w-full">
            {submitting ? 'Please wait…' : mode === 'signin' ? 'Sign in' : 'Create account'}
          </button>
        </form>

        <p className="text-sm text-ink-700 mt-5 text-center">
          {mode === 'signin' ? (
            <>New here? <button className="text-azure-600 font-medium" onClick={() => setMode('signup')}>Create an account</button></>
          ) : (
            <>Already have an account? <button className="text-azure-600 font-medium" onClick={() => setMode('signin')}>Sign in</button></>
          )}
        </p>
        <p className="text-center mt-4">
          <Link to="/" className="text-sm text-ink-700/60 hover:text-ink-700">← Back</Link>
        </p>
      </div>
    </div>
  )
}
