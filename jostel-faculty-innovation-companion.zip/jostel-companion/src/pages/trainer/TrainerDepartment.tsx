import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import AppShell from '../../components/AppShell'
import { supabase } from '../../lib/supabase'
import type { Department, UserRow } from '../../types/domain'

export default function TrainerDepartment() {
  const { id } = useParams()
  const [department, setDepartment] = useState<Department | null>(null)
  const [faculty, setFaculty] = useState<UserRow[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!id) return
    Promise.all([
      supabase.from('departments').select('*').eq('id', id).single(),
      supabase.from('faculty_profiles').select('users(*)').eq('department_id', id),
    ]).then(([d, f]) => {
      setDepartment(d.data ?? null)
      setFaculty((f.data ?? []).map((r: any) => r.users).filter(Boolean))
      setLoading(false)
    })
  }, [id])

  if (loading) return <AppShell><p className="text-ink-700">Loading…</p></AppShell>

  return (
    <AppShell>
      <div className="max-w-2xl">
        <p className="text-sm text-tangerine-600 font-medium mb-1">Trainer workspace</p>
        <h1 className="text-3xl mb-6">{department?.name}</h1>

        <h2 className="text-xl mb-3">Faculty</h2>
        {faculty.length === 0 && <p className="text-ink-700">No faculty profiles are linked to this department yet.</p>}
        <div className="space-y-3">
          {faculty.map((f) => (
            <Link key={f.id} to={`/trainer/faculty/${f.id}`} className="surface-card hover:border-tangerine-300 transition block">
              <p className="font-display text-lg text-ink-900">{f.name}</p>
              <p className="text-sm text-ink-700">{f.email}</p>
            </Link>
          ))}
        </div>
      </div>
    </AppShell>
  )
}
