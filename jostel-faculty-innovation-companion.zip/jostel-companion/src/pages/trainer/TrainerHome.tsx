import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import AppShell from '../../components/AppShell'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import type { Department } from '../../types/domain'

export default function TrainerHome() {
  const { session } = useAuth()
  const [departments, setDepartments] = useState<Department[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!session) return
    supabase
      .from('trainer_departments')
      .select('departments(*)')
      .eq('trainer_id', session.user.id)
      .then(({ data }) => {
        setDepartments((data ?? []).map((r: any) => r.departments).filter(Boolean))
        setLoading(false)
      })
  }, [session])

  return (
    <AppShell>
      <div className="max-w-2xl">
        <h1 className="text-3xl mb-1">My JosTEL support</h1>
        <p className="text-ink-700 mb-6">Departments assigned to me</p>

        {loading && <p className="text-ink-700">Loading…</p>}
        {!loading && departments.length === 0 && (
          <p className="text-ink-700">
            No departments are assigned to you yet — ask an admin to assign you from Admin → Departments.
          </p>
        )}

        <div className="grid sm:grid-cols-2 gap-4">
          {departments.map((d) => (
            <Link key={d.id} to={`/trainer/departments/${d.id}`} className="surface-card hover:border-tangerine-300 transition">
              <p className="font-display text-lg text-ink-900">{d.name}</p>
              {d.description && <p className="text-sm text-ink-700">{d.description}</p>}
            </Link>
          ))}
        </div>
      </div>
    </AppShell>
  )
}
