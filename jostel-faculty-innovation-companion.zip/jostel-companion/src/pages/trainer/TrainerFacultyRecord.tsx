import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import AppShell from '../../components/AppShell'
import { supabase } from '../../lib/supabase'
import { useAuth } from '../../contexts/AuthContext'
import type { Activity, TrainerNote, UserRow } from '../../types/domain'
import type { TrainerStatus } from '../../types/database'

const STATUS_OPTIONS: TrainerStatus[] = ['not_started', 'discussed', 'in_progress', 'evidence_collected', 'completed']
const STATUS_LABEL: Record<TrainerStatus, string> = {
  not_started: 'Not started', discussed: 'Discussed', in_progress: 'In progress',
  evidence_collected: 'Evidence collected', completed: 'Completed',
}

const EMPTY: Partial<TrainerNote> = {
  existing_practice: '', suggested_pedagogy: '', suggested_assessment: '', hots_opportunity: '',
  evidence_available: '', evidence_needed: '', notes: '', follow_up: '', follow_up_date: '',
  status: 'not_started',
}

export default function TrainerFacultyRecord() {
  const { id: facultyId } = useParams()
  const { session } = useAuth()
  const [faculty, setFaculty] = useState<UserRow | null>(null)
  const [activities, setActivities] = useState<Activity[]>([])
  const [pastNotes, setPastNotes] = useState<TrainerNote[]>([])
  const [current, setCurrent] = useState<Partial<TrainerNote>>(EMPTY)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [loading, setLoading] = useState(true)

  async function reload() {
    if (!facultyId || !session) return
    const [f, acts, notes] = await Promise.all([
      supabase.from('users').select('*').eq('id', facultyId).single(),
      supabase.from('activities').select('*').eq('faculty_id', facultyId).order('activity_date', { ascending: false }),
      supabase.from('trainer_notes').select('*').eq('faculty_id', facultyId).eq('trainer_id', session.user.id).order('created_at', { ascending: false }),
    ])
    setFaculty(f.data ?? null)
    setActivities(acts.data ?? [])
    setPastNotes(notes.data ?? [])
    setLoading(false)
  }

  useEffect(() => { reload() }, [facultyId, session])

  function startNew() {
    setCurrent(EMPTY)
    setEditingId(null)
  }

  function edit(note: TrainerNote) {
    setCurrent(note)
    setEditingId(note.id)
  }

  async function handleSave() {
    if (!facultyId || !session) return
    setSaving(true)
    const payload = { ...current, trainer_id: session.user.id, faculty_id: facultyId }
    const result = editingId
      ? await supabase.from('trainer_notes').update(payload).eq('id', editingId).select().single()
      : await supabase.from('trainer_notes').insert(payload).select().single()
    setSaving(false)
    if (!result.error) {
      setEditingId(result.data.id)
      setCurrent(result.data)
      reload()
    }
  }

  function update<K extends keyof TrainerNote>(key: K, value: TrainerNote[K]) {
    setCurrent((c) => ({ ...c, [key]: value }))
  }

  if (loading) return <AppShell><p className="text-ink-700">Loading…</p></AppShell>

  return (
    <AppShell>
      <div className="max-w-2xl">
        <p className="text-sm text-tangerine-600 font-medium mb-1">Faculty support</p>
        <h1 className="text-3xl mb-1">{faculty?.name}</h1>
        <p className="text-ink-700 mb-8">{faculty?.email}</p>

        {activities.length > 0 && (
          <section className="surface-card mb-6">
            <h2 className="text-lg mb-3">Their reports</h2>
            <ul className="space-y-1.5 text-sm">
              {activities.map((a) => (
                <li key={a.id} className="flex justify-between">
                  <span>{a.title}</span>
                  <span className="text-ink-700/60">{a.activity_date}</span>
                </li>
              ))}
            </ul>
          </section>
        )}

        <section className="surface-card mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl">{editingId ? 'Edit session notes' : 'New support session'}</h2>
            {editingId && <button className="text-sm text-azure-600" onClick={startNew}>Start a new session instead</button>}
          </div>

          <div className="space-y-5">
            <div>
              <p className="field-label">Discover — "What are you already doing differently in your classroom?"</p>
              <textarea className="field-input" rows={2} value={current.existing_practice ?? ''} onChange={(e) => update('existing_practice', e.target.value)} />
            </div>
            <div>
              <p className="field-label">Strengthen — "What small change could make the learning more active or higher-order?"</p>
              <textarea className="field-input" rows={2} value={current.suggested_pedagogy ?? ''} onChange={(e) => update('suggested_pedagogy', e.target.value)} />
            </div>
            <div>
              <p className="field-label">Thinking — HOTS opportunity identified</p>
              <textarea className="field-input" rows={2} value={current.hots_opportunity ?? ''} onChange={(e) => update('hots_opportunity', e.target.value)} />
            </div>
            <div>
              <p className="field-label">Assessment — "How are you currently assessing this, and how could it improve?"</p>
              <textarea className="field-input" rows={2} value={current.suggested_assessment ?? ''} onChange={(e) => update('suggested_assessment', e.target.value)} />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <p className="field-label">Evidence already available</p>
                <textarea className="field-input" rows={2} value={current.evidence_available ?? ''} onChange={(e) => update('evidence_available', e.target.value)} />
              </div>
              <div>
                <p className="field-label">Evidence still needed</p>
                <textarea className="field-input" rows={2} value={current.evidence_needed ?? ''} onChange={(e) => update('evidence_needed', e.target.value)} />
              </div>
            </div>
            <div>
              <p className="field-label">Additional notes</p>
              <textarea className="field-input" rows={2} value={current.notes ?? ''} onChange={(e) => update('notes', e.target.value)} />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <p className="field-label">Follow-up — "What will you try next?"</p>
                <input className="field-input" value={current.follow_up ?? ''} onChange={(e) => update('follow_up', e.target.value)} />
              </div>
              <div>
                <p className="field-label">Follow-up date</p>
                <input type="date" className="field-input" value={current.follow_up_date ?? ''} onChange={(e) => update('follow_up_date', e.target.value)} />
              </div>
            </div>
            <div>
              <p className="field-label">Status</p>
              <select className="field-input" value={current.status ?? 'not_started'} onChange={(e) => update('status', e.target.value as TrainerStatus)}>
                {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
              </select>
            </div>
          </div>

          <button className="btn-primary mt-5" disabled={saving} onClick={handleSave}>
            {saving ? 'Saving…' : 'Save session'}
          </button>
        </section>

        {pastNotes.length > 0 && (
          <section>
            <h2 className="text-xl mb-3">Previous interactions</h2>
            <ul className="space-y-3">
              {pastNotes.map((n) => (
                <li key={n.id}>
                  <button onClick={() => edit(n)} className="surface-card w-full text-left hover:border-azure-300 transition">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm text-ink-700/60">{new Date(n.created_at).toLocaleDateString()}</span>
                      <span className="pill bg-azure-50 text-azure-700">{STATUS_LABEL[n.status]}</span>
                    </div>
                    <p className="text-sm text-ink-700 line-clamp-2">{n.existing_practice || n.notes || 'No summary recorded.'}</p>
                  </button>
                </li>
              ))}
            </ul>
          </section>
        )}
      </div>
    </AppShell>
  )
}
