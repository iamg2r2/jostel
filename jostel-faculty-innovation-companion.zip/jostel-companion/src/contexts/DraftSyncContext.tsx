import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'

interface DraftSyncValue {
  isOnline: boolean
}

const DraftSyncContext = createContext<DraftSyncValue>({ isOnline: true })

export function DraftSyncProvider({ children }: { children: ReactNode }) {
  const [isOnline, setIsOnline] = useState(navigator.onLine)

  useEffect(() => {
    const goOnline = () => setIsOnline(true)
    const goOffline = () => setIsOnline(false)
    window.addEventListener('online', goOnline)
    window.addEventListener('offline', goOffline)
    return () => {
      window.removeEventListener('online', goOnline)
      window.removeEventListener('offline', goOffline)
    }
  }, [])

  return (
    <DraftSyncContext.Provider value={{ isOnline }}>
      {!isOnline && (
        <div className="fixed bottom-0 inset-x-0 z-50 bg-ink-900 text-white text-sm text-center py-2 px-4">
          You're offline. Draft saved on this device — it will sync when you reconnect.
        </div>
      )}
      {children}
    </DraftSyncContext.Provider>
  )
}

export function useDraftSync() {
  return useContext(DraftSyncContext)
}
