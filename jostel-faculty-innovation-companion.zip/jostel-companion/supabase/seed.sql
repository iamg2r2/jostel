-- ============================================================================
-- JosTEL Faculty Innovation Companion — seed data
-- Run AFTER supabase/schema.sql. Safe to re-run (uses upserts on unique names).
-- Replace/extend the departments list with your college's actual 31
-- departments whenever convenient — nothing else in the schema hard-codes them.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- Departments (10 seeded as real examples; add the rest from Admin -> Departments)
-- ---------------------------------------------------------------------------
insert into departments (name, description) values
  ('Computer Science', 'BSc, BCA and MCA programmes'),
  ('Counselling Psychology', 'UG and PG psychology and counselling programmes'),
  ('Physics', 'UG and PG physics programmes'),
  ('English', 'Department of English Language and Literature'),
  ('Commerce', 'B.Com and related commerce programmes'),
  ('Management Studies', 'BBA and MBA programmes'),
  ('Mathematics', 'UG and PG mathematics programmes'),
  ('Chemistry', 'UG and PG chemistry programmes'),
  ('Social Work', 'BSW and MSW programmes'),
  ('Visual Communication', 'UG media and visual communication programmes')
on conflict (name) do nothing;

-- ---------------------------------------------------------------------------
-- Pedagogy library (19 approaches)
-- ---------------------------------------------------------------------------
insert into pedagogies (name, description, general_guidance, classroom_example, quick_plan) values

('Project-Based Learning',
 'Students work over an extended period to investigate and respond to an authentic, complex question or problem, producing a real artefact or outcome.',
 'Works best when there is a genuine audience or use for the final product, not just a grade. Keep the driving question open enough that teams can make real decisions.',
 'Ask students to design a small web application that solves a real problem faced by first-year students on campus.',
 '0-10 min: introduce the driving question and success criteria. 10-25 min: teams form and draft an initial approach. 25-45 min: teams investigate requirements and sketch a solution. 45-55 min: quick peer feedback round. 55-60 min: each team notes next steps for the following session.'),

('Problem-Based Learning',
 'Students are given an ill-structured, realistic problem before any formal instruction, and learn the underlying content as they work out how to solve it.',
 'The problem should not have one obvious "textbook" answer. Faculty acts as a facilitator, prompting with questions rather than supplying the solution.',
 'Present a scenario — "a small business''s website has been hacked" — and ask groups to diagnose likely causes and propose a fix before discussing security concepts formally.',
 '0-10 min: present the problem, no lecture. 10-20 min: groups list what they already know and what they need to find out. 20-45 min: guided investigation with resources. 45-55 min: groups present their working hypothesis. 55-60 min: instructor bridges to the formal concept.'),

('Challenge-Based Learning',
 'A broad real-world challenge is narrowed by students into a specific, actionable problem they investigate and prototype a solution for.',
 'Good for units that end in a showcase. Keep an eye on scope — student-chosen challenges can balloon quickly.',
 'Pose the challenge "make our department more sustainable" and let teams narrow it to a specific, solvable slice such as reducing printed handouts.',
 '0-10 min: frame the broad challenge. 10-20 min: teams narrow it to one concrete, solvable slice. 20-45 min: research and prototype. 45-55 min: share narrowed challenge + first idea. 55-60 min: instructor feedback on scope.'),

('Experiential Learning',
 'Students learn primarily through direct experience and structured reflection on that experience, following a do–reflect–conceptualise–apply cycle.',
 'The reflection step is not optional — without it, experience alone rarely produces deeper learning. Always build in a debrief.',
 'Have students conduct a short mock client interview, then reflect in writing on what they would do differently.',
 '0-15 min: the experience/activity itself. 15-30 min: structured individual reflection (guided prompts). 30-45 min: small-group discussion of patterns noticed. 45-60 min: whole-class synthesis of principles to carry forward.'),

('Flipped Classroom',
 'Students engage with foundational content (a video, reading, or module) before class, freeing class time for application, discussion and problem-solving.',
 'The pre-class material must be genuinely necessary for the in-class activity to work, or students will stop doing it.',
 'Assign a short recorded explanation of a concept as homework, then use class time entirely for worked problems and peer teaching.',
 '0-10 min: quick check on the pre-class material (poll or short quiz). 10-40 min: application activity in pairs or small groups. 40-55 min: instructor circulates and addresses misconceptions. 55-60 min: exit ticket.'),

('Peer Instruction',
 'Students answer a conceptual question individually, discuss it in pairs, then answer again — surfacing and correcting misconceptions through peer explanation.',
 'Choose questions where a common misconception produces a plausible wrong answer; that gap is where the learning happens.',
 'Pose a conceptual multiple-choice question on a topic, have students vote, discuss with a neighbour, then vote again.',
 '0-5 min: pose the conceptual question, individual vote. 5-15 min: pair discussion ("convince your neighbour"). 15-20 min: re-vote and reveal. 20-30 min: instructor addresses the most common remaining misconception.'),

('Collaborative Learning',
 'Small groups work together toward a shared goal, with individual accountability built in so participation is genuine rather than assumed.',
 'Structure roles (e.g. summariser, sceptic, recorder) so group work does not default to one student doing everything.',
 'Assign each group a sub-topic to teach back to the class, with rotating roles inside the group.',
 '0-10 min: assign groups, roles and the shared goal. 10-35 min: group work. 35-50 min: groups report out. 50-60 min: individual reflection or quick check for understanding.'),

('Design Thinking',
 'A human-centred process — empathise, define, ideate, prototype, test — used to develop solutions grounded in real user needs.',
 'The empathise stage is often skipped under time pressure; protect at least a short version of it or the "solutions" tend to be generic.',
 'Have students interview a classmate about a genuine frustration with the library system, then sketch one small improvement.',
 '0-10 min: quick empathy interviews in pairs. 10-15 min: define the core problem in one sentence. 15-35 min: ideate and sketch. 35-50 min: build a rough prototype (paper is fine). 50-60 min: test with another pair and note feedback.'),

('Simulation',
 'Students act within a realistic, rule-bound scenario that mimics a real system or situation, making decisions and seeing consequences play out.',
 'Debrief thoroughly afterward — the learning is often in comparing what happened to what students expected.',
 'Run a short market or negotiation simulation and compare outcomes across groups afterward.',
 '0-10 min: explain the scenario and rules. 10-40 min: run the simulation. 40-50 min: compare outcomes across groups. 50-60 min: debrief — what real-world principle did this illustrate?'),

('Hackathon-Based Learning',
 'A short, intense, time-boxed sprint where teams build a working prototype addressing a defined problem, ending in a showcase.',
 'Works best as a one-off intensive event rather than a weekly format; make sure judging criteria value learning and process, not just polish.',
 'Run a half-day build sprint where teams create a working prototype addressing a problem chosen from a shortlist.',
 'Best run as a longer block: kickoff and team formation, a build sprint with scheduled mentor check-ins, then a lightning-round showcase and peer voting.'),

('Case-Based Learning',
 'Students analyse a detailed, realistic case — often with ambiguity or competing considerations — and work through it using course concepts.',
 'A good case has enough detail to feel real and enough ambiguity that reasonable people could disagree on the right course of action.',
 'Present an anonymised client case and ask students to identify the presenting issue, relevant theory, and a possible intervention plan.',
 '0-10 min: read/introduce the case. 10-30 min: small-group analysis using a structured framework. 30-50 min: groups present their analysis and recommendation. 50-60 min: compare approaches and discuss what the case leaves unresolved.'),

('AI-Supported Learning',
 'Students use AI tools transparently as part of an activity — for drafting, feedback, ideation or practice — with explicit reflection on what the tool got right or wrong.',
 'Always pair AI use with a verification or critique step; the goal is to build judgement about the tool, not just output.',
 'Ask students to get an AI-generated first draft of a short explanation, then critique and correct it against the textbook.',
 '0-10 min: frame the task and boundaries of AI use. 10-25 min: generate + critique the AI output. 25-45 min: revise using their own understanding. 45-60 min: share what the AI got wrong and why.'),

('Role Play',
 'Students take on defined roles or perspectives and act out a scenario, building perspective-taking and applied understanding.',
 'Give clear role briefs so students can commit to the perspective rather than defaulting to their own opinion.',
 'Assign students roles in a client–counsellor scenario and have them role-play a first session, then discuss what was hard about it.',
 '0-10 min: assign roles and briefs. 10-30 min: role play in pairs or small groups. 30-45 min: rotate roles if useful. 45-60 min: debrief on what the role play revealed.'),

('Reflective Learning',
 'Structured reflection — written or discussed — helps students connect experience to concepts and notice their own growth over time.',
 'Give a specific prompt rather than "reflect on today''s class"; vague prompts produce vague reflections.',
 'After a practicum or lab session, have students write a short structured reflection using a "what / so what / now what" prompt.',
 '0-5 min: introduce the specific reflection prompt. 5-25 min: individual written reflection. 25-45 min: optional small-group sharing. 45-60 min: whole-class synthesis of common themes.'),

('Socratic Discussion',
 'The instructor guides a discussion through a sequence of probing questions rather than lecturing, pushing students to examine and justify their reasoning.',
 'Plan your question sequence in advance; the "spontaneous" feel of a good Socratic discussion usually comes from careful preparation.',
 'Lead a discussion on a text or case using only questions, pressing students to justify claims with evidence.',
 '0-5 min: pose the opening question. 5-40 min: guided questioning, following student reasoning. 40-55 min: press toward a synthesis question. 55-60 min: students write one sentence capturing their current view.'),

('Inquiry-Based Learning',
 'Students generate their own questions about a phenomenon and investigate them, with the instructor guiding rather than supplying answers upfront.',
 'Resist the urge to explain the phenomenon early; let genuine curiosity and investigation happen first.',
 'Show a puzzling physical phenomenon and have students generate questions and design a way to test one of them.',
 '0-10 min: present the phenomenon, no explanation. 10-20 min: students generate questions. 20-45 min: investigate one question in groups. 45-60 min: share findings and compare to initial predictions.'),

('Laboratory-Based Learning',
 'Students conduct hands-on experiments or practical work to test concepts directly, developing both technical skill and conceptual understanding.',
 'Build in a prediction step before the experiment runs — comparing prediction to result is where much of the learning happens.',
 'Have students predict an experimental outcome before running it, then reconcile any mismatch with the underlying theory.',
 '0-10 min: predict the outcome and reasoning. 10-40 min: conduct the experiment. 40-50 min: compare result to prediction. 50-60 min: write a short explanation of any mismatch.'),

('Dialogic Learning',
 'Understanding is built collaboratively through sustained, open dialogue between students and instructor, with meaning negotiated rather than transmitted.',
 'Requires genuinely open questions and a classroom norm that changing your mind in discussion is a sign of thinking, not losing.',
 'Facilitate an open dialogue on a poem or text where interpretations are built collaboratively rather than delivered by the instructor.',
 '0-10 min: shared opening prompt or text. 10-40 min: open dialogue, instructor as participant-facilitator. 40-55 min: small groups distil the discussion into a shared statement. 55-60 min: share statements.'),

('Debate-Based Learning',
 'Students research and argue assigned or chosen positions on a genuine question, then critique arguments and evidence, sometimes switching sides.',
 'Assigning a position (rather than letting students pick) builds the skill of arguing a case on its merits, not just personal opinion.',
 'Assign sides on a genuine debatable question, have students argue their assigned position, then have them argue the opposite side.',
 '0-10 min: assign positions and question. 10-25 min: prepare arguments in teams. 25-45 min: structured debate. 45-55 min: switch-side round or open rebuttal. 55-60 min: debrief on strongest arguments heard, regardless of side.')

on conflict (name) do nothing;

-- ---------------------------------------------------------------------------
-- Pedagogy steps (10-step implementation sequence for the most commonly
-- used approaches — extend the rest from Admin -> Pedagogies as needed)
-- ---------------------------------------------------------------------------

insert into pedagogy_steps (pedagogy_id, step_number, title, description)
select p.id, s.step_number, s.title, s.description
from pedagogies p
join (values
  (1, 'Define the learning outcome', 'Decide exactly what students should know or be able to do by the end, in plain language.'),
  (2, 'Present the authentic problem', 'Frame a real, specific problem or brief — not a hypothetical exercise.'),
  (3, 'Form teams', 'Group students with attention to balance of skills; assign roles if helpful.'),
  (4, 'Investigate requirements', 'Teams gather the information and constraints they need before designing a solution.'),
  (5, 'Design the solution', 'Teams sketch or plan their approach and get quick instructor feedback before building.'),
  (6, 'Develop a prototype', 'Teams build a working (even if rough) version of their solution.'),
  (7, 'Conduct peer or faculty review', 'A structured check-in where teams get feedback before finalising.'),
  (8, 'Revise', 'Teams act on feedback — this step should not be skipped for time.'),
  (9, 'Present', 'Teams share their finished work with a real or simulated audience.'),
  (10, 'Reflect', 'Students individually note what they learned and what they would do differently.')
) as s(step_number, title, description) on true
where p.name = 'Project-Based Learning'
on conflict (pedagogy_id, step_number) do nothing;

insert into pedagogy_steps (pedagogy_id, step_number, title, description)
select p.id, s.step_number, s.title, s.description
from pedagogies p
join (values
  (1, 'Select a genuine problem', 'Choose a realistic, ill-structured problem with no single obvious answer.'),
  (2, 'Present without pre-teaching', 'Give students the problem before any formal lecture on the topic.'),
  (3, 'Surface prior knowledge', 'Groups list what they already know and what they still need to find out.'),
  (4, 'Guide the investigation', 'Point students toward resources; resist supplying the answer directly.'),
  (5, 'Develop a working hypothesis', 'Groups draft their best current explanation or solution.'),
  (6, 'Test and refine', 'Groups check their hypothesis against new information or evidence.'),
  (7, 'Present reasoning', 'Groups explain not just their answer but how they got there.'),
  (8, 'Bridge to formal concepts', 'Instructor connects the group work explicitly to the course''s formal content.'),
  (9, 'Apply to a new case', 'A quick follow-up problem checks whether the concept transfers.'),
  (10, 'Reflect on the process', 'Students note what strategies helped them work through ambiguity.')
) as s(step_number, title, description) on true
where p.name = 'Problem-Based Learning'
on conflict (pedagogy_id, step_number) do nothing;

insert into pedagogy_steps (pedagogy_id, step_number, title, description)
select p.id, s.step_number, s.title, s.description
from pedagogies p
join (values
  (1, 'Introduce the case', 'Give students the full case with enough detail to feel real.'),
  (2, 'First read and clarify', 'Students identify facts, stakeholders and the core issue individually.'),
  (3, 'Apply a framework', 'Introduce or recall a structured framework to analyse the case.'),
  (4, 'Small-group analysis', 'Groups work through the framework together.'),
  (5, 'Identify competing considerations', 'Groups explicitly name the trade-offs, not just one right answer.'),
  (6, 'Draft a recommendation', 'Groups commit to a specific, justified course of action.'),
  (7, 'Present and defend', 'Groups present and take questions from peers.'),
  (8, 'Compare approaches', 'The class compares different groups'' recommendations and reasoning.'),
  (9, 'Reveal what happened (if known)', 'Share the real outcome, if the case is based on a real event.'),
  (10, 'Reflect on judgement', 'Students note what made this case genuinely hard to resolve.')
) as s(step_number, title, description) on true
where p.name = 'Case-Based Learning'
on conflict (pedagogy_id, step_number) do nothing;

insert into pedagogy_steps (pedagogy_id, step_number, title, description)
select p.id, s.step_number, s.title, s.description
from pedagogies p
join (values
  (1, 'Choose the pre-class material', 'Pick a short video, reading or module that covers the foundational content.'),
  (2, 'Set a low-stakes check', 'Add a brief quiz or poll so students engage with the material before class.'),
  (3, 'Open with the check', 'Start class by reviewing the pre-class check, addressing gaps briefly.'),
  (4, 'Design the application activity', 'Plan the in-class task that requires having done the pre-work.'),
  (5, 'Run the activity in groups', 'Students apply the concept to problems, cases or discussion.'),
  (6, 'Circulate and diagnose', 'Instructor moves around addressing misconceptions in real time.'),
  (7, 'Mid-point check', 'A quick pulse-check on progress partway through the activity.'),
  (8, 'Peer teaching', 'Students who grasp it explain to those still working through it.'),
  (9, 'Close with an exit ticket', 'A short prompt checking what stuck.'),
  (10, 'Adjust next pre-class material', 'Use the exit ticket to refine what to assign before the next class.')
) as s(step_number, title, description) on true
where p.name = 'Flipped Classroom'
on conflict (pedagogy_id, step_number) do nothing;

insert into pedagogy_steps (pedagogy_id, step_number, title, description)
select p.id, s.step_number, s.title, s.description
from pedagogies p
join (values
  (1, 'Empathise', 'Gather real perspectives from the people the solution is meant to serve.'),
  (2, 'Define', 'State the problem in one clear, human-centred sentence.'),
  (3, 'Set constraints', 'Agree on the scope and any real limitations to design within.'),
  (4, 'Ideate widely', 'Generate many possible directions before narrowing.'),
  (5, 'Select a direction', 'Choose one idea to pursue, with reasons.'),
  (6, 'Prototype roughly', 'Build a quick, low-fidelity version — paper is fine.'),
  (7, 'Test with real users', 'Get feedback from someone outside the design team.'),
  (8, 'Iterate', 'Revise based on what testing revealed.'),
  (9, 'Share the outcome', 'Present the solution and the reasoning behind it.'),
  (10, 'Reflect on the process', 'Note which stage most changed the final direction.')
) as s(step_number, title, description) on true
where p.name = 'Design Thinking'
on conflict (pedagogy_id, step_number) do nothing;

-- ---------------------------------------------------------------------------
-- Department fit mapping (a representative set — extend from Admin)
-- ---------------------------------------------------------------------------

insert into pedagogy_department_mapping (pedagogy_id, department_id, fit_type, reason)
select ped.id, dep.id, m.fit_type, m.reason
from (values
  ('Project-Based Learning', 'Computer Science', 'strong', 'Software work is naturally project-shaped. Example: ask students to design a web application that solves a real problem faced by first-year students.'),
  ('Problem-Based Learning', 'Computer Science', 'also_consider', 'Good for debugging-style thinking. Example: present a scenario where "a small business''s website has been hacked" and have groups diagnose likely causes.'),
  ('Challenge-Based Learning', 'Computer Science', 'also_consider', 'Suits open-ended systems problems with room to scope down.'),
  ('Hackathon-Based Learning', 'Computer Science', 'also_consider', 'A natural fit for a one-off intensive build event tied to a course milestone.'),
  ('Peer Instruction', 'Computer Science', 'also_consider', 'Works well for surfacing misconceptions in programming logic and complexity concepts.'),
  ('AI-Supported Learning', 'Computer Science', 'also_consider', 'Students can critique AI-generated code against correctness and style, building judgement about the tool.'),
  ('Case-Based Learning', 'Counselling Psychology', 'strong', 'Case work mirrors real practice directly. Example: present an anonymised client case and ask students to identify the presenting issue and a possible intervention plan.'),
  ('Role Play', 'Counselling Psychology', 'also_consider', 'Builds applied skill in a low-stakes setting before real client work. Example: role-play a first counselling session, then debrief what was hard.'),
  ('Reflective Learning', 'Counselling Psychology', 'also_consider', 'Reflective practice is itself a core professional skill in this field.'),
  ('Experiential Learning', 'Counselling Psychology', 'also_consider', 'A short mock interview followed by structured reflection builds felt understanding.'),
  ('Simulation', 'Counselling Psychology', 'also_consider', 'Useful for practising responses to realistic (simulated) client scenarios.'),
  ('Socratic Discussion', 'Counselling Psychology', 'also_consider', 'Helps students examine and justify their reasoning about ethical or clinical judgement calls.'),
  ('Inquiry-Based Learning', 'Physics', 'strong', 'Physics phenomena invite genuine student-generated questions before formal explanation.'),
  ('Laboratory-Based Learning', 'Physics', 'strong', 'Predicting an outcome before running the experiment sharpens conceptual understanding.'),
  ('Problem-Based Learning', 'Physics', 'also_consider', 'Realistic physical scenarios can motivate the need for a formal concept.'),
  ('Simulation', 'Physics', 'also_consider', 'Simulated systems let students see consequences of variable changes safely.'),
  ('Flipped Classroom', 'Physics', 'also_consider', 'Frees class time for problem-solving rather than derivations.'),
  ('Collaborative Learning', 'Physics', 'also_consider', 'Group problem sets support peer explanation of tricky derivations.'),
  ('Project-Based Learning', 'Physics', 'also_consider', 'Example: design and test an investigation into a physical phenomenon of the students'' choosing.'),
  ('Dialogic Learning', 'English', 'strong', 'Literary meaning is well suited to being built collaboratively through open dialogue.'),
  ('Socratic Discussion', 'English', 'strong', 'Close reading benefits from sustained, probing questioning rather than lecture.'),
  ('Debate-Based Learning', 'English', 'also_consider', 'Genuinely debatable interpretive or thematic questions build argumentation skill.'),
  ('Project-Based Learning', 'English', 'also_consider', 'Example: create a digital literary exhibition around a theme or author.'),
  ('Reflective Learning', 'English', 'also_consider', 'Personal response writing benefits from structured reflective prompts.'),
  ('Case-Based Learning', 'English', 'also_consider', 'Useful for applied writing/communication modules with realistic scenarios.'),
  ('Case-Based Learning', 'Commerce', 'strong', 'Business cases mirror real decision-making with competing considerations.'),
  ('Simulation', 'Commerce', 'strong', 'Market or trading simulations let students see consequences of decisions.'),
  ('Problem-Based Learning', 'Commerce', 'also_consider', 'Realistic business problems motivate the underlying concepts.'),
  ('Project-Based Learning', 'Commerce', 'also_consider', 'Example: develop a business plan for a local enterprise.'),
  ('Debate-Based Learning', 'Commerce', 'also_consider', 'Policy and ethics questions in commerce are genuinely debatable.'),
  ('Role Play', 'Commerce', 'also_consider', 'Negotiation and client scenarios build applied skill.'),
  ('Case-Based Learning', 'Management Studies', 'strong', 'The case method is a long-standing core method in management education.'),
  ('Simulation', 'Management Studies', 'strong', 'Business simulations let students test strategy decisions safely.'),
  ('Role Play', 'Management Studies', 'also_consider', 'Useful for negotiation, leadership and HR scenarios.'),
  ('Project-Based Learning', 'Management Studies', 'also_consider', 'Consulting-style projects mirror real management work.'),
  ('Debate-Based Learning', 'Management Studies', 'also_consider', 'Strategic trade-off questions are genuinely debatable.'),
  ('Inquiry-Based Learning', 'Mathematics', 'strong', 'Letting students explore a pattern before naming the theorem builds deeper understanding.'),
  ('Problem-Based Learning', 'Mathematics', 'strong', 'A well-chosen problem can motivate an entire unit''s concepts.'),
  ('Peer Instruction', 'Mathematics', 'also_consider', 'Conceptual questions with plausible wrong answers surface common misconceptions.'),
  ('Flipped Classroom', 'Mathematics', 'also_consider', 'Frees class time for worked problems rather than derivations.'),
  ('Collaborative Learning', 'Mathematics', 'also_consider', 'Group problem-solving supports peer explanation.'),
  ('Laboratory-Based Learning', 'Chemistry', 'strong', 'Hands-on experimentation is central to developing chemical intuition.'),
  ('Inquiry-Based Learning', 'Chemistry', 'strong', 'Student-generated questions about reactions build genuine curiosity.'),
  ('Problem-Based Learning', 'Chemistry', 'also_consider', 'Realistic chemical scenarios motivate formal concepts.'),
  ('Simulation', 'Chemistry', 'also_consider', 'Useful where real experiments are hazardous or resource-intensive.'),
  ('Case-Based Learning', 'Social Work', 'strong', 'Practice-based case analysis mirrors real fieldwork decisions.'),
  ('Experiential Learning', 'Social Work', 'strong', 'Direct experience with structured reflection is core to social work pedagogy.'),
  ('Role Play', 'Social Work', 'also_consider', 'Builds applied interviewing and intervention skill safely.'),
  ('Reflective Learning', 'Social Work', 'also_consider', 'Reflective practice is itself a professional competency here.'),
  ('Design Thinking', 'Visual Communication', 'strong', 'A human-centred process maps directly onto design practice.'),
  ('Project-Based Learning', 'Visual Communication', 'strong', 'Portfolio-building work is naturally project-based.'),
  ('Collaborative Learning', 'Visual Communication', 'also_consider', 'Studio-style critique and teamwork mirror industry practice.'),
  ('Case-Based Learning', 'Visual Communication', 'also_consider', 'Analysing real campaigns builds critical and applied understanding.')
) as m(pedagogy_name, department_name, fit_type, reason)
join pedagogies ped on ped.name = m.pedagogy_name
join departments dep on dep.name = m.department_name
on conflict (pedagogy_id, department_id) do nothing;

-- ---------------------------------------------------------------------------
-- Assessment library (16 approaches)
-- ---------------------------------------------------------------------------

insert into assessments (name, description, measures, when_to_use, how_to_conduct, rubric_criteria, evidence_produced) values
('Performance Task', 'A realistic task where students demonstrate a skill in action rather than answer questions about it.', 'Application, practical skill', 'When you want evidence of doing, not just knowing.', 'Set a realistic task with clear success criteria; observe or review the output.', 'Accuracy, process, adherence to constraints', 'Completed task artefact, observation notes'),
('Project', 'An extended piece of work, usually over multiple sessions, producing a substantial artefact.', 'Application, creation, planning', 'For extended, multi-step learning goals.', 'Define milestones; check in periodically; assess the final artefact and process.', 'Depth, originality, execution, reflection', 'Project artefact, milestone drafts'),
('Case Analysis', 'Students analyse a realistic case and produce a reasoned response or recommendation.', 'Analysis, evaluation, applied judgement', 'When decision-making under ambiguity is the target skill.', 'Provide the case and a structured framework; assess the written or presented analysis.', 'Use of evidence, reasoning, awareness of trade-offs', 'Written or presented case analysis'),
('Viva', 'An oral examination where students explain and defend their reasoning or work.', 'Depth of understanding, ability to defend reasoning', 'When you need to verify understanding behind submitted work.', 'Prepare a short set of probing questions tied to the work submitted.', 'Clarity, depth, ability to handle follow-up questions', 'Recorded or noted responses'),
('Portfolio', 'A curated collection of work over time showing growth and range.', 'Growth, range, self-selection of best work', 'For courses spanning a semester or longer.', 'Ask students to select and annotate their strongest pieces with reasoning.', 'Range, reflection on growth, quality of selected pieces', 'Curated artefacts with annotations'),
('Peer Assessment', 'Students assess each other''s work against shared criteria.', 'Collaboration, critical evaluation skill', 'Alongside group work, to build evaluative judgement.', 'Give clear criteria and a simple structured form; calibrate with an example first.', 'Constructiveness, alignment with criteria', 'Peer feedback forms'),
('Self Assessment', 'Students assess their own work or process against shared criteria.', 'Metacognition, self-awareness', 'Paired with a reflective or portfolio task.', 'Ask students to rate and justify their own work against the same rubric used for grading.', 'Honesty, specificity, alignment with actual performance', 'Self-assessment form'),
('Reflective Journal', 'Ongoing written reflection connecting experience to concepts over time.', 'Reflection, growth over time', 'For practicum, fieldwork or extended experiential units.', 'Set a regular cadence and specific prompts, not open-ended "write about today".', 'Specificity, connection to concepts, evidence of change over time', 'Journal entries'),
('Debate', 'Students argue assigned positions on a genuine question, then respond to counter-arguments.', 'Argumentation, use of evidence, communication', 'For genuinely debatable questions with multiple defensible positions.', 'Assign sides, give prep time, run a structured format with rebuttal.', 'Quality of evidence, responsiveness to counter-arguments, clarity', 'Debate performance, prep notes'),
('Presentation', 'Students present work orally, often with visual support, to an audience.', 'Communication, synthesis', 'When conveying findings clearly to others is itself a target skill.', 'Set time limits and clear criteria; consider audience Q&A.', 'Clarity, structure, engagement with questions', 'Slides/recording, presentation notes'),
('Simulation', 'Students are assessed on decisions and outcomes within a realistic simulated scenario.', 'Applied decision-making under realistic constraints', 'When real-world practice is impractical, risky or slow.', 'Run the simulation, then assess both the outcome and the reasoning behind key decisions.', 'Quality of decisions, adaptation to changing conditions', 'Simulation log, debrief notes'),
('Practical Demonstration', 'Students physically demonstrate a skill or technique.', 'Practical skill, technique', 'For lab, studio or hands-on technical skills.', 'Observe the demonstration against a clear checklist of technique steps.', 'Technique accuracy, safety, efficiency', 'Observation checklist, photos/video where appropriate'),
('Milestone Assessment', 'Work is assessed at defined checkpoints throughout a longer project rather than only at the end.', 'Process, iterative progress', 'For extended projects where early course-correction matters.', 'Define 2-4 checkpoints in advance with clear expectations at each.', 'Progress against plan, responsiveness to earlier feedback', 'Checkpoint submissions'),
('Rubric-Based Assessment', 'Any task assessed against an explicit, shared rubric with defined performance levels.', 'Whatever the rubric criteria specify', 'Whenever consistent, transparent grading criteria matter — pairs well with any other method here.', 'Share the rubric before the task; assess consistently against its levels.', 'As defined per rubric', 'Completed rubric with scores/comments'),
('Quiz-Based Assessment', 'A short, low-stakes set of questions checking recall or basic application.', 'Knowledge, basic application', 'For quick checks, not for assessing higher-order thinking alone.', 'Keep it brief and frequent rather than high-stakes and rare.', 'Accuracy', 'Quiz responses'),
('Concept Map Assessment', 'Students represent relationships between concepts visually, showing structural understanding.', 'Structural/relational understanding', 'When how ideas connect matters as much as the ideas themselves.', 'Ask students to build and briefly explain a concept map; look for relationships, not just nodes.', 'Accuracy of relationships, completeness, organisation', 'Concept map artefact')
on conflict (name) do nothing;
