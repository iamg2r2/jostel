-- ============================================================================
-- JosTEL Faculty Innovation Companion — database schema
-- Run this in the Supabase SQL editor (or via `supabase db push`) on a fresh
-- project, BEFORE loading supabase/seed.sql.
-- ============================================================================

create extension if not exists "uuid-ossp";

-- ---------------------------------------------------------------------------
-- Core reference tables
-- ---------------------------------------------------------------------------

create table if not exists departments (
  id uuid primary key default uuid_generate_v4(),
  name text not null unique,
  description text,
  created_at timestamptz not null default now()
);

-- Mirrors auth.users; a row is created here by the handle_new_user() trigger
-- below whenever someone signs up through Supabase Auth.
create table if not exists users (
  id uuid primary key references auth.users (id) on delete cascade,
  name text not null,
  email text not null,
  role text not null default 'faculty' check (role in ('faculty', 'trainer', 'admin')),
  created_at timestamptz not null default now()
);

create table if not exists faculty_profiles (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references users (id) on delete cascade unique,
  department_id uuid references departments (id) on delete set null,
  designation text
);

create table if not exists trainer_departments (
  trainer_id uuid not null references users (id) on delete cascade,
  department_id uuid not null references departments (id) on delete cascade,
  primary key (trainer_id, department_id)
);

-- ---------------------------------------------------------------------------
-- Pedagogy & assessment libraries
-- ---------------------------------------------------------------------------

create table if not exists pedagogies (
  id uuid primary key default uuid_generate_v4(),
  name text not null unique,
  description text not null,        -- "What is it?" / "When might it help?"
  general_guidance text,            -- notes that apply across disciplines
  classroom_example text,           -- a generic "try this in your class" example
  quick_plan text,                  -- the 60-minute-version timing breakdown
  created_at timestamptz not null default now()
);

create table if not exists pedagogy_department_mapping (
  id uuid primary key default uuid_generate_v4(),
  pedagogy_id uuid not null references pedagogies (id) on delete cascade,
  department_id uuid not null references departments (id) on delete cascade,
  fit_type text not null check (fit_type in ('strong', 'also_consider')),
  reason text not null,             -- why it fits here + a discipline-specific example
  unique (pedagogy_id, department_id)
);

create table if not exists pedagogy_steps (
  id uuid primary key default uuid_generate_v4(),
  pedagogy_id uuid not null references pedagogies (id) on delete cascade,
  step_number int not null,
  title text not null,
  description text not null,
  unique (pedagogy_id, step_number)
);

create table if not exists assessments (
  id uuid primary key default uuid_generate_v4(),
  name text not null unique,
  description text not null,        -- what it measures / when to use / how to conduct
  measures text,
  when_to_use text,
  how_to_conduct text,
  rubric_criteria text,
  evidence_produced text,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- Activities, evidence, trainer notes
-- ---------------------------------------------------------------------------

create table if not exists activities (
  id uuid primary key default uuid_generate_v4(),
  faculty_id uuid not null references users (id) on delete cascade,
  trainer_id uuid references users (id) on delete set null,
  department_id uuid references departments (id) on delete set null,
  course_code text,
  course_name text,
  semester text,
  class_name text,
  num_students int,
  activity_date date not null default current_date,
  title text not null default 'Untitled activity',
  pedagogy_id uuid references pedagogies (id) on delete set null,
  assessment_id uuid references assessments (id) on delete set null,
  thinking_level text check (thinking_level in ('LOTS', 'MOTS', 'HOTS')),
  description text,
  learning_outcome text,
  implementation text,
  assessment_notes text,
  student_outcome text,
  reflection text,
  status text not null default 'draft' check (status in ('draft', 'in_progress', 'completed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists evidence (
  id uuid primary key default uuid_generate_v4(),
  activity_id uuid not null references activities (id) on delete cascade,
  file_name text not null,
  storage_path text not null,
  file_type text not null,
  uploaded_at timestamptz not null default now()
);

create table if not exists trainer_notes (
  id uuid primary key default uuid_generate_v4(),
  trainer_id uuid not null references users (id) on delete cascade,
  faculty_id uuid not null references users (id) on delete cascade,
  activity_id uuid references activities (id) on delete set null,
  existing_practice text,
  suggested_pedagogy text,
  suggested_assessment text,
  hots_opportunity text,
  evidence_available text,
  evidence_needed text,
  notes text,
  follow_up text,
  follow_up_date date,
  status text not null default 'not_started'
    check (status in ('not_started', 'discussed', 'in_progress', 'evidence_collected', 'completed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- updated_at triggers
-- ---------------------------------------------------------------------------

create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_activities_updated_at on activities;
create trigger trg_activities_updated_at before update on activities
  for each row execute function set_updated_at();

drop trigger if exists trg_trainer_notes_updated_at on trainer_notes;
create trigger trg_trainer_notes_updated_at before update on trainer_notes
  for each row execute function set_updated_at();

-- ---------------------------------------------------------------------------
-- New-user handling: every Supabase Auth sign-up gets a row in public.users.
-- Role defaults to 'faculty'; promote to 'trainer'/'admin' from the Admin
-- screen (or directly in the table) after the account exists.
-- ---------------------------------------------------------------------------

create or replace function handle_new_user()
returns trigger as $$
begin
  insert into public.users (id, name, email, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'name', split_part(new.email, '@', 1)),
    new.email,
    coalesce(new.raw_user_meta_data ->> 'role', 'faculty')
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- ---------------------------------------------------------------------------
-- Storage bucket for evidence uploads
-- ---------------------------------------------------------------------------

insert into storage.buckets (id, name, public)
values ('evidence', 'evidence', false)
on conflict (id) do nothing;

-- ============================================================================
-- Row Level Security
-- ============================================================================

alter table users enable row level security;
alter table departments enable row level security;
alter table faculty_profiles enable row level security;
alter table trainer_departments enable row level security;
alter table pedagogies enable row level security;
alter table pedagogy_department_mapping enable row level security;
alter table pedagogy_steps enable row level security;
alter table assessments enable row level security;
alter table activities enable row level security;
alter table evidence enable row level security;
alter table trainer_notes enable row level security;

-- Helper: current user's role, used inside policies below.
create or replace function current_role_name()
returns text as $$
  select role from public.users where id = auth.uid();
$$ language sql stable security definer;

-- Helper: is the current user a trainer assigned to this faculty member's department?
create or replace function is_assigned_trainer(target_faculty_id uuid)
returns boolean as $$
  select exists (
    select 1
    from trainer_departments td
    join faculty_profiles fp on fp.department_id = td.department_id
    where td.trainer_id = auth.uid()
      and fp.user_id = target_faculty_id
  );
$$ language sql stable security definer;

-- users: everyone can read their own row; admins read all; trainers read
-- faculty in their assigned departments (needed to show names).
create policy "users read own" on users for select using (id = auth.uid());
create policy "users read admin" on users for select using (current_role_name() = 'admin');
create policy "users read assigned faculty" on users for select
  using (is_assigned_trainer(id));
create policy "users update own" on users for update using (id = auth.uid());
create policy "users admin manage" on users for all using (current_role_name() = 'admin');

-- Reference libraries: readable by any authenticated user, writable by admins.
create policy "departments read" on departments for select using (auth.role() = 'authenticated');
create policy "departments admin write" on departments for insert with check (current_role_name() = 'admin');
create policy "departments admin update" on departments for update using (current_role_name() = 'admin');
create policy "departments admin delete" on departments for delete using (current_role_name() = 'admin');

create policy "pedagogies read" on pedagogies for select using (auth.role() = 'authenticated');
create policy "pedagogies admin write" on pedagogies for insert with check (current_role_name() = 'admin');
create policy "pedagogies admin update" on pedagogies for update using (current_role_name() = 'admin');
create policy "pedagogies admin delete" on pedagogies for delete using (current_role_name() = 'admin');

create policy "mapping read" on pedagogy_department_mapping for select using (auth.role() = 'authenticated');
create policy "mapping admin write" on pedagogy_department_mapping for insert with check (current_role_name() = 'admin');
create policy "mapping admin update" on pedagogy_department_mapping for update using (current_role_name() = 'admin');
create policy "mapping admin delete" on pedagogy_department_mapping for delete using (current_role_name() = 'admin');

create policy "steps read" on pedagogy_steps for select using (auth.role() = 'authenticated');
create policy "steps admin write" on pedagogy_steps for insert with check (current_role_name() = 'admin');
create policy "steps admin update" on pedagogy_steps for update using (current_role_name() = 'admin');
create policy "steps admin delete" on pedagogy_steps for delete using (current_role_name() = 'admin');

create policy "assessments read" on assessments for select using (auth.role() = 'authenticated');
create policy "assessments admin write" on assessments for insert with check (current_role_name() = 'admin');
create policy "assessments admin update" on assessments for update using (current_role_name() = 'admin');
create policy "assessments admin delete" on assessments for delete using (current_role_name() = 'admin');

-- faculty_profiles: own row; trainers can see profiles in assigned departments; admin all.
create policy "profile read own" on faculty_profiles for select using (user_id = auth.uid());
create policy "profile read trainer" on faculty_profiles for select using (is_assigned_trainer(user_id));
create policy "profile read admin" on faculty_profiles for select using (current_role_name() = 'admin');
create policy "profile write own" on faculty_profiles for insert with check (user_id = auth.uid());
create policy "profile update own" on faculty_profiles for update using (user_id = auth.uid());
create policy "profile admin manage" on faculty_profiles for all using (current_role_name() = 'admin');

-- trainer_departments: trainers read their own assignments; admin manages all.
create policy "trainer_dept read own" on trainer_departments for select using (trainer_id = auth.uid());
create policy "trainer_dept admin manage" on trainer_departments for all using (current_role_name() = 'admin');

-- activities: faculty manage their own; assigned trainers can read + comment
-- via trainer_notes (not edit the activity itself); admin reads all.
create policy "activities crud own" on activities for all
  using (faculty_id = auth.uid())
  with check (faculty_id = auth.uid());
create policy "activities read trainer" on activities for select
  using (is_assigned_trainer(faculty_id));
create policy "activities read admin" on activities for select
  using (current_role_name() = 'admin');

-- evidence: access follows the parent activity's access rules.
create policy "evidence crud via activity" on evidence for all
  using (
    exists (
      select 1 from activities a
      where a.id = evidence.activity_id and a.faculty_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from activities a
      where a.id = evidence.activity_id and a.faculty_id = auth.uid()
    )
  );
create policy "evidence read trainer" on evidence for select
  using (
    exists (
      select 1 from activities a
      where a.id = evidence.activity_id and is_assigned_trainer(a.faculty_id)
    )
  );
create policy "evidence read admin" on evidence for select using (current_role_name() = 'admin');

-- trainer_notes: the assigned trainer manages their own notes; the faculty
-- member the notes are about can read (but not edit) them; admin reads all.
create policy "notes crud own trainer" on trainer_notes for all
  using (trainer_id = auth.uid())
  with check (trainer_id = auth.uid() and is_assigned_trainer(faculty_id));
create policy "notes read faculty" on trainer_notes for select using (faculty_id = auth.uid());
create policy "notes read admin" on trainer_notes for select using (current_role_name() = 'admin');

-- ---------------------------------------------------------------------------
-- Storage policies for the "evidence" bucket.
-- Files are stored under a path like  {activity_id}/{filename}
-- ---------------------------------------------------------------------------

create policy "evidence storage insert own"
  on storage.objects for insert
  with check (
    bucket_id = 'evidence'
    and exists (
      select 1 from activities a
      where a.id::text = (storage.foldername(name))[1]
        and a.faculty_id = auth.uid()
    )
  );

create policy "evidence storage read own"
  on storage.objects for select
  using (
    bucket_id = 'evidence'
    and (
      exists (
        select 1 from activities a
        where a.id::text = (storage.foldername(name))[1]
          and a.faculty_id = auth.uid()
      )
      or exists (
        select 1 from activities a
        where a.id::text = (storage.foldername(name))[1]
          and is_assigned_trainer(a.faculty_id)
      )
      or current_role_name() = 'admin'
    )
  );

create policy "evidence storage delete own"
  on storage.objects for delete
  using (
    bucket_id = 'evidence'
    and exists (
      select 1 from activities a
      where a.id::text = (storage.foldername(name))[1]
        and a.faculty_id = auth.uid()
    )
  );
